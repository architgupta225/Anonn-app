import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { 
  Share2, 
  Bookmark, 
  Flag, 
  Link2, 
  Twitter, 
  Facebook,
  MoreHorizontal
} from "lucide-react";

interface ShareSaveReportProps {
  type: "post" | "organization" | "bowl";
  id: number;
  title: string;
  url?: string;
}

export default function ShareSaveReport({ type, id, title, url }: ShareSaveReportProps) {
  const { toast } = useToast();
  const [showReportDialog, setShowReportDialog] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  
  const currentUrl = url || window.location.href;
  
  const handleShare = (platform: string) => {
    const encodedTitle = encodeURIComponent(title);
    const encodedUrl = encodeURIComponent(currentUrl);
    
    let shareUrl = "";
    
    switch (platform) {
      case "copy":
        navigator.clipboard.writeText(currentUrl);
        toast({
          title: "Link copied!",
          description: "The link has been copied to your clipboard.",
        });
        return;
      case "twitter":
        shareUrl = `https://twitter.com/intent/tweet?text=${encodedTitle}&url=${encodedUrl}`;
        break;
      case "facebook":
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`;
        break;
      case "linkedin":
        shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`;
        break;
    }
    
    if (shareUrl) {
      window.open(shareUrl, "_blank", "width=600,height=400");
    }
  };

  const handleSave = () => {
    // TODO: Implement save functionality with backend
    setIsSaved(!isSaved);
    toast({
      title: isSaved ? "Removed from saved" : "Saved successfully!",
      description: isSaved 
        ? `${title} has been removed from your saved items.`
        : `${title} has been saved to your profile.`,
    });
  };

  const handleReport = () => {
    // TODO: Implement report functionality with backend
    setShowReportDialog(false);
    toast({
      title: "Report submitted",
      description: "Thank you for your report. We'll review this content shortly.",
    });
  };

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button 
            variant="ghost" 
            size="sm"
            className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
          >
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          {/* Share Options */}
          <DropdownMenuItem onClick={() => handleShare("copy")}>
            <Link2 className="h-4 w-4 mr-2" />
            Copy Link
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleShare("twitter")}>
            <Twitter className="h-4 w-4 mr-2" />
            Share on Twitter
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleShare("facebook")}>
            <Facebook className="h-4 w-4 mr-2" />
            Share on Facebook
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => handleShare("linkedin")}>
            <Share2 className="h-4 w-4 mr-2" />
            Share on LinkedIn
          </DropdownMenuItem>
          
          <DropdownMenuSeparator />
          
          {/* Save Option */}
          <DropdownMenuItem onClick={handleSave}>
            <Bookmark className={`h-4 w-4 mr-2 ${isSaved ? 'fill-current' : ''}`} />
            {isSaved ? 'Remove from Saved' : 'Save'}
          </DropdownMenuItem>
          
          <DropdownMenuSeparator />
          
          {/* Report Option */}
          <DropdownMenuItem 
            onClick={() => setShowReportDialog(true)}
            className="text-red-600 dark:text-red-400"
          >
            <Flag className="h-4 w-4 mr-2" />
            Report
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Report Dialog */}
      <AlertDialog open={showReportDialog} onOpenChange={setShowReportDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Report Content</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to report this {type}? This will notify our moderation team 
              to review the content for violations of our community guidelines.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleReport} className="bg-red-600 hover:bg-red-700">
              Submit Report
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}