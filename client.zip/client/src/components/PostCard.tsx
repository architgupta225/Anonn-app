import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import VoteButtons from "@/components/VoteButtons";

import { 
  MessageSquare, 
  Share2, 
  Bookmark, 
  Clock,
  Building,
  Users,
  User,
  BarChart3,
  ChevronRight
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import type { PostWithDetails } from "@shared/schema";

interface PostCardProps {
  post: PostWithDetails;
  onUpdate: () => void;
}

export default function PostCard({ post, onUpdate }: PostCardProps) {



  const getPostTypeLabel = () => {
    if (post.type === 'review') return 'Discussion';
    if (post.type === 'poll') return 'Poll';
    return 'Discussion';
  };

  const handlePollClick = () => {
    if (post.type === 'poll') {
      // Navigate to the individual poll page using the post ID
      // The poll and post are created together, so we can use the post ID
      console.log('Poll clicked! Navigating to:', `/poll?id=${post.id}`);
      window.location.href = `/poll?id=${post.id}`;
    }
  };

  const truncateContent = (content: string, maxLength: number = 300) => {
    if (content.length <= maxLength) return content;
    return content.substring(0, maxLength).trim() + '...';
  };

  const shouldTruncate = post.content.length > 300;
  const displayContent = truncateContent(post.content);

  const getAuthorDisplay = () => {
    if (post.isAnonymous) {
      return "anonymous";
    }
    
    const author = post.author;
    if (author.firstName && author.lastName) {
      return `${author.firstName} ${author.lastName}`;
    }
    
    return author.email?.split('@')[0] || 'User';
  };



  return (
    <div className="flex items-start space-x-4 hover:bg-gray-50 dark:hover:bg-slate-800/30 transition-all duration-300 rounded-xl p-4" onClick={() => {
      if (post.type === 'poll') {
        window.location.href = `/poll?id=${post.id}`;
      } else {
        window.location.href = `/post?id=${post.id}`;
      }
    }}> 
      {/* Vote Buttons */}
      <div className="transform hover:scale-105 transition-transform duration-300" onClick={(e) => e.stopPropagation()}>
        <VoteButtons 
          targetId={post.id}
          targetType="post"
          upvotes={post.upvotes}
          downvotes={post.downvotes}
          userVote={post.userVote}
          onUpdate={onUpdate}
        />
      </div>

      {/* Post Content */}
      <div className="flex-1">
        {/* Post Meta */}
        <div className="flex items-center space-x-2 mb-3 flex-wrap">
          {post.type === 'poll' && (
            <Badge className="bg-gradient-to-r from-blue-500 to-purple-600 text-white text-xs px-3 py-1 font-medium">
              <BarChart3 className="w-3 h-3 mr-1" />
              Poll
            </Badge>
          )}
          <span className="text-sm text-muted-foreground">
            {getPostTypeLabel()} • Posted by
          </span>
          <div className="flex items-center space-x-1">
            {!post.isAnonymous && post.author.profileImageUrl ? (
              <Avatar className="h-5 w-5">
                <AvatarImage src={post.author.profileImageUrl} />
                <AvatarFallback>
                  <User className="h-2 w-2" />
                </AvatarFallback>
              </Avatar>
            ) : null}
            <button
              onClick={(e) => {
                e.stopPropagation();
                window.open(`/profile?id=${post.author.id}`, '_blank');
              }}
              className="text-sm font-medium text-reddit-orange hover:text-reddit-orange/80 hover:underline cursor-pointer"
            >
              {getAuthorDisplay()}
            </button>
          </div>
          <span className="text-sm text-muted-foreground flex items-center">
            <Clock className="h-3 w-3 mr-1" />
            {formatDistanceToNow(new Date(post.createdAt || ''), { addSuffix: true })}
          </span>
          {post.organization && (
            <>
              <span className="text-sm text-muted-foreground">in</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  window.open(`/organization?id=${post.organization!.id}`, '_blank');
                }}
                className="flex items-center space-x-1 bg-muted px-2 py-1 rounded-full hover:bg-muted/80 cursor-pointer"
              >
                <Building className="h-3 w-3 text-professional-blue" />
                <span className="text-sm font-medium text-professional-blue hover:underline">
                  {post.organization.name}
                </span>
              </button>
            </>
          )}
          {post.bowl && (
            <>
              <span className="text-sm text-muted-foreground">in</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  window.open(`/bowl?id=${post.bowl!.id}`, '_blank');
                }}
                className="flex items-center space-x-1 bg-muted px-2 py-1 rounded-full hover:bg-muted/80 cursor-pointer"
              >
                <Users className="h-3 w-3 text-reddit-orange" />
                <span className="text-sm font-medium text-reddit-orange hover:underline">
                  {post.bowl.name}
                </span>
              </button>
            </>
          )}
        </div>

        {/* Post Title */}
        <h2 className="text-xl font-bold text-foreground mb-3 leading-tight">
          {post.title}
        </h2>
        
        {/* Post Content */}
        {post.type === 'poll' ? (
          <div className="mb-4">
            {/* Compact Poll Preview */}
            <div 
              className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 border border-blue-200 dark:border-blue-800 rounded-lg p-3 cursor-pointer hover:shadow-md transition-all duration-300"
              onClick={(e) => {
                e.stopPropagation();
                handlePollClick();
              }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                    <BarChart3 className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h3 className="font-medium text-foreground text-sm">Poll</h3>
                    <p className="text-xs text-muted-foreground line-clamp-2">
                      {post.content.length > 100 ? post.content.substring(0, 100) + '...' : post.content}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-1 text-blue-600 dark:text-blue-400">
                  <span className="text-xs font-medium">View</span>
                  <ChevronRight className="w-3 h-3" />
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-muted-foreground mb-4 leading-relaxed">
            <div className="whitespace-pre-wrap">
              {displayContent.split('\n').map((line, index) => {
                // Check if line contains a URL
                const urlRegex = /(https?:\/\/[^\s]+)/g;
                const parts = line.split(urlRegex);
                
                return (
                  <div key={index} className="mb-1">
                    {parts.map((part, partIndex) => {
                      if (urlRegex.test(part)) {
                        return (
                          <a
                            key={partIndex}
                            href={part}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 underline break-all"
                            onClick={(e) => e.stopPropagation()}
                          >
                            {part}
                          </a>
                        );
                      }
                      return part;
                    })}
                  </div>
                );
              })}
            </div>
            {shouldTruncate && (
              <Button
                variant="link"
                className="p-0 h-auto text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium"
                onClick={(e) => {
                  e.stopPropagation();
                  window.location.href = `/post?id=${post.id}`;
                }}
              >
                Read more
              </Button>
            )}
          </div>
        )}

        {/* Attached Image */}
        {post.imageUrl && (
          <img 
            src={post.imageUrl} 
            alt="Post attachment" 
            className="rounded-lg mb-4 w-full max-h-96 object-cover shadow-lg"
          />
        )}

        {/* Post Actions */}
        <div className="flex items-center space-x-6 text-muted-foreground text-sm" onClick={(e) => e.stopPropagation()}>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => window.location.href = `/post?id=${post.id}`}
            className="flex items-center space-x-1 hover:text-professional-blue p-2 rounded-lg transition-all duration-300"
          >
            <MessageSquare className="h-4 w-4" />
            <span>{post.commentCount} comments</span>
          </Button>
          
          <Button 
            variant="ghost" 
            size="sm"
            className="flex items-center space-x-1 hover:text-reddit-orange p-2 rounded-lg transition-all duration-300"
          >
            <Share2 className="h-4 w-4" />
            <span>Share</span>
          </Button>
          
          <Button 
            variant="ghost" 
            size="sm"
            className="flex items-center space-x-1 hover:text-positive p-2 rounded-lg transition-all duration-300"
          >
            <Bookmark className="h-4 w-4" />
            <span>Save</span>
          </Button>
        </div>
      </div>
    </div>
  );
}
