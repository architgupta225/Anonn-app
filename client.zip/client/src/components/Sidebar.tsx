import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { 
  Plus, Building, Users, TrendingUp, Star, Home, Shield, 
  BarChart3, MessageCircle, Sparkles, Globe, Briefcase, 
  Building2, Users2, Archive, Flame, Edit3, Clock, MessageSquare
} from "lucide-react";
import { Link, useLocation } from "wouter";
import type { Bowl, Organization, BowlFollow } from "@shared/schema";

interface SidebarProps {
  onCreatePost: () => void;
  onCreateReview: () => void;
  onToggleSidebar: () => void;
  isOpen: boolean;
}

export default function Sidebar({ onCreatePost, onCreateReview, onToggleSidebar, isOpen }: SidebarProps) {
  const [location] = useLocation();
  const queryClient = useQueryClient();
  const [favorites, setFavorites] = useState<Set<number>>(new Set());
  
  // Load favorites from server on component mount
  const { data: serverFavorites } = useQuery<{ bowlId: number }[]>({
    queryKey: ["/api/user/favorites"],
    retry: false,
    enabled: true, // Load from server
  });

  // Load favorites from localStorage on component mount
  useEffect(() => {
    const savedFavorites = localStorage.getItem('bowl-favorites');
    if (savedFavorites) {
      try {
        const favoritesArray = JSON.parse(savedFavorites);
        setFavorites(new Set(favoritesArray));
      } catch (error) {
        console.error('Error loading favorites from localStorage:', error);
      }
    }
  }, []);

  // Sync with server favorites when available
  useEffect(() => {
    if (serverFavorites) {
      const serverFavoritesSet = new Set(serverFavorites.map(f => f.bowlId));
      setFavorites(serverFavoritesSet);
      localStorage.setItem('bowl-favorites', JSON.stringify(Array.from(serverFavoritesSet)));
    }
  }, [serverFavorites]);
  
  const { data: bowls, isLoading: bowlsLoading } = useQuery<Bowl[]>({
    queryKey: ["/api/bowls"],
    retry: false,
  });

  const { data: organizations, isLoading: orgsLoading } = useQuery<Organization[]>({
    queryKey: ["/api/organizations"],
    retry: false,
  });

  // Get user's followed bowls
  const { data: userBowls } = useQuery<(BowlFollow & { bowl: Bowl })[]>({
    queryKey: ["/api/user/bowls"],
    retry: false,
  });

  // Mutation for updating favorites
  const updateFavoriteMutation = useMutation({
    mutationFn: async ({ bowlId, isFavorite }: { bowlId: number; isFavorite: boolean }) => {
      const response = await fetch('/api/user/favorites', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ bowlId, isFavorite }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to update favorite');
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Invalidate and refetch user bowls and favorites to get updated data
      queryClient.invalidateQueries({ queryKey: ["/api/user/bowls"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/favorites"] });
    },
  });

  const handleFavorite = (bowlId: number) => {
    const isCurrentlyFavorite = favorites.has(bowlId);
    const newFavorites = new Set(favorites);
    
    if (isCurrentlyFavorite) {
      newFavorites.delete(bowlId);
    } else {
      newFavorites.add(bowlId);
    }
    
    setFavorites(newFavorites);
    
    // Save to localStorage
    localStorage.setItem('bowl-favorites', JSON.stringify(Array.from(newFavorites)));
    
    // Update on server
    updateFavoriteMutation.mutate({ bowlId, isFavorite: !isCurrentlyFavorite });
  };

  // Get top bowls by member count
  const popularBowls = bowls?.slice(0, 3) || [];

  // Get top organizations (mock trending for now)
  const trendingOrgs = organizations?.slice(0, 3) || [];

  // Sort user bowls to show favorites first, then by most recently followed
  const sortedUserBowls = userBowls ? [...userBowls].sort((a, b) => {
    const aIsFavorite = favorites.has(a.bowl.id);
    const bIsFavorite = favorites.has(b.bowl.id);
    
    // First sort by favorites
    if (aIsFavorite && !bIsFavorite) return -1;
    if (!aIsFavorite && bIsFavorite) return 1;
    
    // Then sort by most recently followed
    if (a.followedAt && b.followedAt) {
      return new Date(b.followedAt).getTime() - new Date(a.followedAt).getTime();
    }
    
    return 0;
  }) : [];

  // Debug log to see what bowls we have
  console.log('User bowls:', userBowls?.length || 0, 'Sorted bowls:', sortedUserBowls.length);
  if (sortedUserBowls.length > 0) {
    console.log('Recent bowls:', sortedUserBowls.slice(0, 3).map(b => ({
      name: b.bowl.name,
      followedAt: b.followedAt,
      isFavorite: favorites.has(b.bowl.id)
    })));
  }

  const sidebarItems = [
    { href: "/", label: "Feed", icon: Home, isActive: location === "/" },
    { href: "/polls", label: "Polls", icon: BarChart3, isActive: location === "/polls" },
    { href: "/featured", label: "Featured Content", icon: Sparkles, isActive: location === "/featured" },
    { href: "/trending", label: "Trending", icon: TrendingUp, isActive: location === "/trending" },
  ];

  const filterItems = [
  ];

  return (
    <div className="w-full bg-white dark:bg-slate-800 border-r border-gray-200 dark:border-slate-700 pt-6">
      {/* Sidebar Toggle Button */}
      <div className="flex justify-between items-center px-4 mb-4">
        {isOpen && <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Navigation</h2>}
        <button
          onClick={onToggleSidebar}
          className={`p-1 rounded-md hover:bg-gray-100 dark:hover:bg-slate-700 ${!isOpen ? 'mx-auto' : ''}`}
        >
          <svg className="w-5 h-5 text-gray-600 dark:text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} />
          </svg>
        </button>
      </div>

      {/* Main Navigation */}
      <nav className="space-y-1 px-4">
        {sidebarItems.map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors duration-200 ${
                item.isActive
                  ? "bg-reddit-orange/10 text-reddit-orange border-r-3 border-reddit-orange"
                  : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white"
              } ${!isOpen ? 'justify-center' : ''}`}
              title={!isOpen ? item.label : undefined}
            >
              <Icon className={`h-5 w-5 flex-shrink-0 ${isOpen ? 'mr-3' : ''}`} />
              {isOpen && item.label}
            </Link>
          );
        })}
      </nav>

      {/* Black divider line */}
      <div className="my-4 mx-4 h-px bg-black dark:bg-white"></div>

      {/* User's Followed Bowls - RECENT Section */}
      {sortedUserBowls && sortedUserBowls.length > 0 && (
        <div className="px-4">
          {isOpen && (
            <h3 className="px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>RECENT</span>
              <button className="p-1 hover:bg-gray-100 dark:hover:bg-slate-700 rounded">
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
            </h3>
          )}
          <nav className="space-y-1">
            {sortedUserBowls.slice(0, 3).map((userBowl) => (
              <div key={userBowl.bowl.id} className={`flex items-center ${isOpen ? 'justify-between' : 'justify-center'} px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 rounded-md hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white transition-colors duration-200`}>
                <Link href={`/bowls/${userBowl.bowl.id}`} className={`flex items-center ${isOpen ? 'flex-1 min-w-0' : ''}`} title={!isOpen ? userBowl.bowl.name : undefined}>
                  <div className="w-6 h-6 bg-reddit-orange rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                    <span className="text-white text-xs font-bold">{userBowl.bowl.name?.charAt(0).toUpperCase() || '?'}</span>
                  </div>
                  {isOpen && (
                    <span className="truncate flex-1 min-w-0">
                      r/{userBowl.bowl.name?.toLowerCase().replace(/\s+/g, '') || 'unknown'}
                    </span>
                  )}
                </Link>
                {isOpen && (
                  <button 
                    className="p-1 hover:bg-gray-200 dark:hover:bg-slate-600 rounded flex-shrink-0 ml-2"
                    onClick={() => handleFavorite(userBowl.bowl.id)}
                  >
                    <svg className={`w-4 h-4 ${favorites.has(userBowl.bowl.id) ? 'text-yellow-500 fill-current' : 'text-gray-400'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                    </svg>
                  </button>
                )}
              </div>
            ))}
          </nav>
        </div>
      )}

      {/* Black divider line */}
      {isOpen && <div className="my-4 mx-4 h-px bg-black dark:bg-white"></div>}

      {/* All User's Followed Bowls - COMMUNITIES Section */}
      {sortedUserBowls && sortedUserBowls.length > 0 && (
        <div className="px-4">
          {isOpen && (
            <h3 className="px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>COMMUNITIES</span>
              <button className="p-1 hover:bg-gray-100 dark:hover:bg-slate-700 rounded">
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
            </h3>
          )}
          <nav className="space-y-1">
            {sortedUserBowls.map((userBowl) => (
              <div key={userBowl.bowl.id} className={`flex items-center ${isOpen ? 'justify-between' : 'justify-center'} px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 rounded-md hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white transition-colors duration-200`}>
                <Link href={`/bowls/${userBowl.bowl.id}`} className={`flex items-center ${isOpen ? 'flex-1 min-w-0' : ''}`} title={!isOpen ? userBowl.bowl.name : undefined}>
                  <div className="w-6 h-6 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                    <span className="text-white text-xs font-bold">{userBowl.bowl.name?.charAt(0).toUpperCase() || '?'}</span>
                  </div>
                  {isOpen && (
                    <span className="truncate flex-1 min-w-0">
                      r/{userBowl.bowl.name?.toLowerCase().replace(/\s+/g, '') || 'unknown'}
                    </span>
                  )}
                </Link>
                {isOpen && (
                  <button 
                    className="p-1 hover:bg-gray-200 dark:hover:bg-slate-600 rounded flex-shrink-0 ml-2"
                    onClick={() => handleFavorite(userBowl.bowl.id)}
                  >
                    <svg className={`w-4 h-4 ${favorites.has(userBowl.bowl.id) ? 'text-yellow-500 fill-current' : 'text-gray-400'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                    </svg>
                  </button>
                )}
              </div>
            ))}
          </nav>
        </div>
      )}
    </div>
  );
}
