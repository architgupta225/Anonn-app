import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ChevronUp, ChevronDown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Vote } from "@shared/schema";

interface VoteButtonsProps {
  targetId: number;
  targetType: "post" | "comment" | "poll";
  upvotes: number;
  downvotes: number;
  userVote?: Vote;
  onUpdate: () => void;
  size?: "default" | "sm";
}

export default function VoteButtons({ 
  targetId, 
  targetType, 
  upvotes, 
  downvotes, 
  userVote, 
  onUpdate,
  size = "default"
}: VoteButtonsProps) {
  const { toast } = useToast();

  const voteMutation = useMutation({
    mutationFn: async (voteType: "up" | "down") => {
      if (targetType === "poll") {
        await apiRequest("POST", `/api/polls/${targetId}/votes`, {
          voteType,
        });
      } else {
        await apiRequest("POST", "/api/vote", {
          targetId,
          targetType,
          voteType,
        });
      }
    },
    onSuccess: () => {
      onUpdate();
      // Invalidate user data to update karma
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to vote. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleVote = (voteType: "up" | "down") => {
    voteMutation.mutate(voteType);
  };

  const getVoteScore = () => {
    return upvotes - downvotes;
  };

  const getScoreColor = () => {
    const score = getVoteScore();
    if (score > 0) return "text-reddit-orange";
    if (score < 0) return "text-negative";
    return "text-gray-600 dark:text-gray-400";
  };

  const iconSize = size === "sm" ? "h-4 w-4" : "h-5 w-5";
  const buttonSize = size === "sm" ? "h-6 w-6" : "h-8 w-8";

  return (
    <div className="flex flex-col items-center space-y-1">
      {/* Upvote Button */}
      <Button
        variant="ghost"
        size="icon"
        disabled={voteMutation.isPending}
        onClick={() => handleVote("up")}
        className={`${buttonSize} p-0 transition-colors ${
          userVote?.voteType === "up"
            ? "text-reddit-orange hover:text-reddit-orange"
            : "text-gray-400 hover:text-reddit-orange"
        }`}
      >
        <ChevronUp className={iconSize} />
      </Button>

      {/* Score */}
      <span className={`text-sm font-medium ${getScoreColor()} transition-colors`}>
        {getVoteScore()}
      </span>

      {/* Downvote Button */}
      <Button
        variant="ghost"
        size="icon"
        disabled={voteMutation.isPending}
        onClick={() => handleVote("down")}
        className={`${buttonSize} p-0 transition-colors ${
          userVote?.voteType === "down"
            ? "text-negative hover:text-negative"
            : "text-gray-400 hover:text-negative"
        }`}
      >
        <ChevronDown className={iconSize} />
      </Button>
    </div>
  );
}
