import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Send, MessageSquare, User } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import VoteButtons from "./VoteButtons";
import type { CommentWithDetails } from "@shared/schema";

const replySchema = z.object({
  content: z.string().min(1, "Reply cannot be empty").max(1000, "Reply must be less than 1000 characters"),
});

type ReplyData = z.infer<typeof replySchema>;

interface CommentReplyProps {
  comment: CommentWithDetails;
  postId: number;
  onSuccess?: () => void;
  depth?: number;
}

export default function CommentReply({ comment, postId, onSuccess, depth = 0 }: CommentReplyProps) {
  const { toast } = useToast();
  const [showReplyForm, setShowReplyForm] = useState(false);
  const maxDepth = 3; // Limit nesting depth

  // Debug: Log what we're receiving
  console.log(`🔍 CommentReply render:`, {
    commentId: comment.id,
    content: comment.content.substring(0, 20) + '...',
    hasReplies: !!comment.replies,
    repliesCount: comment.replies?.length || 0,
    depth,
    parentId: comment.parentId
  });



  const form = useForm<ReplyData>({
    resolver: zodResolver(replySchema),
    defaultValues: {
      content: "",
    }
  });

  const createReplyMutation = useMutation({
    mutationFn: async (data: ReplyData) => {
      const requestData = {
        content: data.content,
        parentId: comment.id,
      };
      console.log('🔥 CREATING REPLY:', {
        parentCommentId: comment.id,
        content: data.content,
        postId,
        requestData
      });
      const response = await apiRequest("POST", `/api/posts/${postId}/comments`, requestData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Reply posted!",
        description: "Your reply has been added successfully",
      });
      form.reset();
      setShowReplyForm(false);
      queryClient.invalidateQueries({ queryKey: ["/api/posts", postId, "comments"] });
      onSuccess?.();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to post reply",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ReplyData) => {
    createReplyMutation.mutate(data);
  };

  const canReply = depth < maxDepth;

  return (
    <div>
      {/* Main comment content */}
      <div className="flex items-start space-x-3 mb-3">
        <div className="flex flex-col items-center space-y-1 mt-1">
          <VoteButtons 
            targetId={comment.id}
            targetType="comment"
            upvotes={comment.upvotes}
            downvotes={comment.downvotes}
            userVote={comment.userVote}
            onUpdate={onSuccess || (() => {})}
            size="sm"
          />
        </div>
        
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <Avatar className="h-6 w-6">
              <AvatarImage src={comment.author.profileImageUrl || undefined} />
              <AvatarFallback>
                <User className="h-3 w-3" />
              </AvatarFallback>
            </Avatar>
            
            <span className="text-sm font-medium text-reddit-orange">
              {comment.author.firstName && comment.author.lastName 
                ? `${comment.author.firstName} ${comment.author.lastName}`
                : comment.author.email?.split('@')[0] || 'User'
              }
            </span>
            
            <span className="text-xs text-muted-foreground">
              {formatDistanceToNow(new Date(comment.createdAt || ''), { addSuffix: true })}
            </span>
          </div>
          
          <div className="text-sm text-foreground whitespace-pre-wrap mb-3">
            {comment.content}
          </div>

          {/* Reply button */}
          {canReply && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowReplyForm(!showReplyForm)}
              className="text-xs text-muted-foreground hover:text-foreground p-1 h-auto"
            >
              <MessageSquare className="h-3 w-3 mr-1" />
              Reply
            </Button>
          )}
        </div>
      </div>

      {/* Reply form - properly nested */}
      {showReplyForm && canReply && (
        <div className={`ml-9 mb-4 ${depth > 0 ? 'border-l-2 border-gray-200 dark:border-slate-700 pl-4' : ''}`}>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
              <FormField
                control={form.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Textarea
                        placeholder="Write a reply..."
                        rows={2}
                        className="resize-none text-sm"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex justify-end space-x-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    setShowReplyForm(false);
                    form.reset();
                  }}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  size="sm"
                  disabled={createReplyMutation.isPending || !form.watch("content").trim()}
                  className="bg-reddit-orange hover:bg-reddit-orange/90"
                >
                  {createReplyMutation.isPending ? (
                    "Posting..."
                  ) : (
                    <>
                      <Send className="h-3 w-3 mr-1" />
                      Reply
                    </>
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      )}

      {/* Nested replies - Reddit style */}
      {comment.replies && comment.replies.length > 0 && (
        <div className="mt-4 ml-8 border-l-2 border-gray-300 dark:border-slate-600 pl-4">
          {console.log(`📝 Rendering ${comment.replies.length} replies for comment ${comment.id}:`, comment.replies.map(r => ({id: r.id, content: r.content.substring(0, 20)})))}
          {comment.replies.map((reply) => (
            <div key={reply.id} className="mb-4">
              <CommentReply
                comment={reply}
                postId={postId}
                onSuccess={onSuccess}
                depth={depth + 1}
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
} 