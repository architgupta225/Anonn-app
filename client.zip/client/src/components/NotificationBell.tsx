import { useEffect, useRef, useState } from "react";
import { Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import type { Notification } from "@shared/schema";

export default function NotificationBell() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const wsRef = useRef<WebSocket | null>(null);

  console.log('NotificationBell: Rendering with notifications:', notifications, 'unreadCount:', unreadCount); // Debug log

  // Fetch notifications on mount
  useEffect(() => {
    console.log('NotificationBell: Fetching notifications...'); // Debug log
    fetch("/api/notifications")
      .then((res) => {
        console.log('NotificationBell: Fetch response:', res.status); // Debug log
        return res.json();
      })
      .then((data: Notification[]) => {
        console.log('NotificationBell: Fetched notifications:', data); // Debug log
        setNotifications(data);
        setUnreadCount(data.filter((n) => !n.read).length);
      })
      .catch((err) => {
        console.error('NotificationBell: Error fetching notifications:', err); // Debug log
      });
  }, []);

  // WebSocket for real-time notifications
  useEffect(() => {
    console.log('NotificationBell: Connecting to websocket...'); // Debug log
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.hostname}:${window.location.port || '3000'}`;
    console.log('NotificationBell: WebSocket URL:', wsUrl); // Debug log
    
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;
    
    ws.onopen = () => {
      console.log('NotificationBell: WebSocket connected'); // Debug log
    };
    
    ws.onerror = (error) => {
      console.error('NotificationBell: WebSocket error:', error); // Debug log
    };
    
    ws.onclose = () => {
      console.log('NotificationBell: WebSocket closed'); // Debug log
    };
    
    ws.onmessage = (event) => {
      try {
        console.log('NotificationBell: Received message:', event.data); // Debug log
        const msg = JSON.parse(event.data);
        if (msg.type === "notification") {
          console.log('NotificationBell: New notification received:', msg.notification); // Debug log
          setNotifications((prev) => [msg.notification, ...prev]);
          setUnreadCount((prev) => prev + 1);
        }
      } catch (err) {
        console.error('NotificationBell: Error parsing message:', err); // Debug log
      }
    };
    return () => ws.close();
  }, []);

  // Mark notification as read
  const markAsRead = async (id: number) => {
    await fetch(`/api/notifications/${id}/read`, { method: "POST" });
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
    setUnreadCount((prev) => Math.max(0, prev - 1));
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-reddit-orange text-white text-xs rounded-full px-1">
              {unreadCount}
            </span>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 max-h-96 overflow-y-auto">
        <div className="font-semibold px-3 py-2">Notifications</div>
        {notifications.length === 0 && (
          <div className="px-3 py-2 text-gray-500">No notifications</div>
        )}
        {notifications.map((n) => (
          <DropdownMenuItem
            key={n.id}
            onClick={() => markAsRead(n.id)}
            className={
              !n.read
                ? "bg-reddit-orange/10 hover:bg-reddit-orange/20 cursor-pointer"
                : "cursor-pointer"
            }
          >
            <div className="flex flex-col">
              <span className="text-sm font-medium">
                {n.content}
              </span>
              <span className="text-xs text-gray-400">
                {n.createdAt ? new Date(n.createdAt).toLocaleString() : ''}
              </span>
            </div>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
} 