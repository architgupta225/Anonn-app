import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button"; 
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Send } from "lucide-react";

const commentSchema = z.object({
  content: z.string().min(1, "Comment cannot be empty").max(1000, "Comment must be less than 1000 characters"),
});

type CommentData = z.infer<typeof commentSchema>;

interface CommentFormProps {
  postId: number;
  onSuccess?: () => void;
}

export default function CommentForm({ postId, onSuccess }: CommentFormProps) {
  const { toast } = useToast();
  const [isExpanded, setIsExpanded] = useState(false);

  const form = useForm<CommentData>({
    resolver: zodResolver(commentSchema),
    defaultValues: {
      content: "",
    }
  });

  const createMutation = useMutation({
    mutationFn: async (data: CommentData) => {
      const response = await apiRequest("POST", `/api/posts/${postId}/comments`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Comment posted!",
        description: "Your comment has been added successfully",
      });
      form.reset();
      setIsExpanded(false);
      // Invalidate comments query to refresh the list
      queryClient.invalidateQueries({ queryKey: ["/api/posts", postId, "comments"] });
      // Call the onSuccess callback to trigger refetch
      onSuccess?.();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to post comment",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CommentData) => {
    createMutation.mutate(data);
  };

  return (
    <div className="mt-4 animate-fade-in">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
          <FormField
            control={form.control}
            name="content"
            render={({ field }) => (
              <FormItem>
                <FormControl>
                  <Textarea
                    placeholder="Add a comment..."
                    rows={isExpanded ? 3 : 1}
                    className="resize-none transition-all duration-200"
                    onFocus={() => setIsExpanded(true)}
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          {isExpanded && (
            <div className="flex justify-end space-x-2 animate-scale-in">
              <Button 
                type="button" 
                variant="outline" 
                size="sm"
                onClick={() => {
                  setIsExpanded(false);
                  form.reset();
                }}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                size="sm"
                disabled={createMutation.isPending || !form.watch("content").trim()}
                className="bg-reddit-orange hover:bg-reddit-orange/90"
              >
                {createMutation.isPending ? (
                  "Posting..."
                ) : (
                  <>
                    <Send className="h-3 w-3 mr-1" />
                    Comment
                  </>
                )}
              </Button>
            </div>
          )}
        </form>
      </Form>
    </div>
  );
}