import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth.tsx";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Flame, Search, Bell, Settings, User, LogOut, TrendingUp, Home, DollarSign, Star, Briefcase, Building2, Edit3 } from "lucide-react";
import NotificationBell from "@/components/NotificationBell";

export default function Navigation() {
  const { user, isAuthenticated } = useAuth();
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement search functionality
    console.log("Search:", searchQuery);
  };

  const getKarmaColor = (karma: number) => {
    if (karma >= 1000) return "text-positive";
    if (karma >= 500) return "text-professional-blue";
    if (karma >= 0) return "text-neutral";
    return "text-negative";
  };

  return (
    <nav className="bg-card dark:bg-background border-b border-gray-200 dark:border-border sticky top-0 z-50">
      <div className="px-4 sm:px-6 lg:px-8 w-full">
        <div className="flex justify-between items-center h-16">
          {/* Logo and Main Navigation */}
          <div className="flex items-center space-x-8">
            <Link href="/" className="flex items-center space-x-2">
              <Flame className="h-8 w-8 text-reddit-orange" />
              <span className="text-2xl font-bold text-gray-900 dark:text-white">Apocalypse</span>
            </Link>
            <div className="hidden md:flex space-x-8">
              <Link 
                href="/"
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  location === "/" 
                    ? "text-reddit-orange" 
                    : "text-gray-700 dark:text-gray-300 hover:text-reddit-orange"
                }`}
              >
                Home
              </Link>
              <Link 
                href="/bowls"
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  location.startsWith("/bowls") 
                    ? "text-reddit-orange" 
                    : "text-gray-700 dark:text-gray-300 hover:text-reddit-orange"
                }`}
              >
                Bowls
              </Link>
              <Link 
                href="/organizations"
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  location.startsWith("/organizations") 
                    ? "text-reddit-orange" 
                    : "text-gray-700 dark:text-gray-300 hover:text-reddit-orange"
                }`}
              >
                Organizations
              </Link>
            </div>
          </div>

          {/* Search Bar */}
          <div className="flex-1 max-w-lg mx-8 hidden md:block">
            <form onSubmit={handleSearch} className="relative">
              <Input
                type="text"
                placeholder="Search organizations, bowls, or reviews..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-reddit-orange focus:border-transparent"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            </form>
          </div>

          {/* User Menu */}
          {isAuthenticated && user ? (
            <div className="flex items-center space-x-4">
              <Link href="/create-post">
                <Button className="bg-reddit-orange hover:bg-reddit-orange/90 text-white font-semibold">
                  <Edit3 className="h-4 w-4 mr-2" />
                  Write a Post
                </Button>
              </Link>
              <NotificationBell />

              <DropdownMenu>
                <DropdownMenuTrigger className="flex items-center space-x-2 hover:bg-gray-50 dark:hover:bg-slate-700 rounded-lg p-2 transition-colors">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={(user as any)?.profileImageUrl || undefined} alt="Profile" />
                    <AvatarFallback>
                      <User className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                  <div className="hidden md:block text-left">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">
                      {(user as any)?.firstName && (user as any)?.lastName 
                        ? `${(user as any).firstName} ${(user as any).lastName}`
                        : (user as any)?.email?.split('@')[0] || 'User'
                      }
                    </div>
                    <div className={`text-xs flex items-center ${getKarmaColor((user as any)?.karma || 0)}`}>
                      <TrendingUp className="h-3 w-3 mr-1" />
                      {(user as any)?.karma || 0} karma
                    </div>
                  </div>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem asChild>
                    <Link href="/profile" className="flex items-center space-x-2 w-full">
                      <User className="h-4 w-4" />
                      <span>Profile</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/settings" className="flex items-center space-x-2 w-full">
                      <Settings className="h-4 w-4" />
                      <span>Settings</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    onClick={() => window.location.href = '/api/auth/logout'}
                    className="flex items-center space-x-2 text-negative"
                  >
                    <LogOut className="h-4 w-4" />
                    <span>Sign Out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          ) : (
            <div className="flex items-center space-x-4">
              <Button 
                onClick={() => window.location.href = '/api/login'}
                className="bg-reddit-orange hover:bg-reddit-orange/90 text-white"
              >
                Sign In
              </Button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
