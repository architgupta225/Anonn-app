import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/hooks/useAuth.tsx";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/landing";
import Home from "@/pages/home";
import Organizations from "@/pages/organizations";
import Organization from "@/pages/organization";
import Bowls from "@/pages/bowls";
import Bowl from "@/pages/bowl";
import Profile from "@/pages/profile";
import Settings from "@/pages/settings";
import AuthPage from "@/pages/auth";
import CreatePost from "@/pages/create-post";
import Polls from "@/pages/polls";
import PollPage from "@/pages/poll";
import PostPage from "@/pages/post";
import Featured from "@/pages/featured";
import Trending from "@/pages/trending";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-orange-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900">
        <div className="relative">
          <div className="h-12 w-12 animate-spin border-4 border-orange-200 border-t-orange-500 rounded-full"></div>
          <div className="absolute inset-0 h-12 w-12 animate-ping border-4 border-orange-300 rounded-full opacity-20"></div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <Switch>
        <Route path="/auth" component={AuthPage} />
        <Route path="/*" component={AuthPage} />
      </Switch>
    );
  }

  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/create-post" component={CreatePost} />
      <Route path="/polls" component={Polls} />
      <Route path="/poll" component={PollPage} />
      <Route path="/post" component={PostPage} />
      <Route path="/featured" component={Featured} />
      <Route path="/trending" component={Trending} />
      <Route path="/organizations" component={Organizations} />
      <Route path="/organizations/:id" component={Organization} />
      <Route path="/organization/:id" component={Organization} />
      <Route path="/bowls" component={Bowls} />
      <Route path="/bowls/:id" component={Bowl} />
      <Route path="/profile" component={Profile} />
      <Route path="/settings" component={Settings} />
      <Route path="/*" component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
