import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Navigation from "@/components/Navigation";
import Sidebar from "@/components/Sidebar";
import PostCard from "@/components/PostCard";
import BowlList from "@/components/BowlList";
import OrganizationList from "@/components/OrganizationList";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Search, MessageSquare, Building, Users, TrendingUp, Sparkles, Edit3, Plus, BarChart3, ThumbsUp } from "lucide-react";
import { useAuth } from "@/hooks/useAuth.tsx";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { PostWithDetails, Bowl, Organization } from "@shared/schema";

export default function Home() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [activeFilter, setActiveFilter] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const handleCreatePost = () => {
    setLocation("/create-post");
  };

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const { data: posts, isLoading, error, refetch } = useQuery<PostWithDetails[]>({
    queryKey: ["/api/posts", activeFilter],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (activeFilter === "reviews") params.set("type", "review");
      if (activeFilter === "discussions") params.set("type", "discussion");
      if (activeFilter === "polls") params.set("type", "poll");
      
      const response = await fetch(`/api/posts?${params.toString()}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error(`${response.status}: ${response.statusText}`);
      }
      
      return response.json();
    },
    retry: false,
  });

  const { data: bowls } = useQuery<Bowl[]>({
    queryKey: ["/api/bowls"],
    retry: false,
  });

  const { data: organizations } = useQuery<Organization[]>({
    queryKey: ["/api/organizations"],
    retry: false,
  });

  // Filter posts based on search term
  const filteredPosts = posts?.filter(post => 
    post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.content.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [error, toast]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex justify-center items-center h-64">
            <div className="text-center animate-pulse">
              <Skeleton className="h-12 w-48 mx-auto mb-4" />
              <Skeleton className="h-6 w-64 mx-auto" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-slate-900">
      <Navigation />
      {/* Main Layout */}
      <div className="flex w-full h-screen">
        {/* Left Sidebar - Fixed position like Blind */}
        <aside className={`${sidebarOpen ? 'w-[240px]' : 'w-[60px]'} h-[calc(100vh-4rem)] sticky top-16 bg-white dark:bg-slate-800 border-r border-gray-200 dark:border-slate-700 overflow-y-auto transition-all duration-300 flex-shrink-0`}>
          <Sidebar 
            onCreatePost={handleCreatePost} 
            onCreateReview={handleCreatePost}
            onToggleSidebar={toggleSidebar}
            isOpen={sidebarOpen}
          />
        </aside>

        {/* Sidebar Toggle Button */}
        <button
          onClick={toggleSidebar}
          className="lg:hidden fixed top-20 left-4 z-40 p-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-md shadow-md hover:bg-gray-50 dark:hover:bg-slate-700"
        >
          <svg className="w-5 h-5 text-gray-600 dark:text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>

        {/* Main Content Area */}
        <main className="flex-1 min-w-0 bg-white dark:bg-slate-900 overflow-y-auto">
          <div className="w-full px-2 sm:px-4 lg:px-8 py-6">
            {/* Write a Post Section - Modern Floating Style */}
            <div className="mb-8 bg-gradient-to-r from-orange-50 to-red-50 dark:from-slate-800 dark:to-slate-700 rounded-2xl p-6 border border-orange-100 dark:border-slate-600 shadow-sm w-full">
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-red-500 rounded-xl flex items-center justify-center shadow-lg">
                  <Edit3 className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1">
                  <Button
                    onClick={handleCreatePost}
                    variant="outline"
                    className="w-full justify-start text-left text-gray-600 dark:text-gray-300 bg-white/80 dark:bg-slate-700/80 border-gray-200 dark:border-slate-600 hover:bg-white dark:hover:bg-slate-700 rounded-xl h-12 text-base"
                  >
                    What's on your mind? Start a conversation...
                  </Button>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex space-x-4">
                  <Button
                    onClick={handleCreatePost}
                    variant="ghost"
                    size="sm"
                    className="text-gray-600 dark:text-gray-400 hover:text-orange-600 dark:hover:text-orange-400 hover:bg-orange-50 dark:hover:bg-slate-700 rounded-lg px-4 py-2"
                  >
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Discussion
                  </Button>
                  
                  <Button
                    onClick={handleCreatePost}
                    variant="ghost"
                    size="sm"
                    className="text-gray-600 dark:text-gray-400 hover:text-orange-600 dark:hover:text-orange-400 hover:bg-orange-50 dark:hover:bg-slate-700 rounded-lg px-4 py-2"
                  >
                    <BarChart3 className="h-4 w-4 mr-2" />
                    Poll
                  </Button>
                </div>
              </div>
            </div>



            {/* Posts Section - Clean Modern Design */}
            <div className="space-y-6 w-full">
              {isLoading ? (
                [1, 2, 3].map((i) => (
                  <div key={i} className="animate-pulse">
                    <div className="flex items-start space-x-4 py-6 border-b border-gray-100 dark:border-slate-700">
                      <Skeleton className="h-10 w-10 rounded-full flex-shrink-0" />
                      <div className="flex-1 space-y-3">
                        <div className="flex items-center space-x-2">
                          <Skeleton className="h-4 w-24" />
                          <Skeleton className="h-3 w-16" />
                        </div>
                        <Skeleton className="h-5 w-3/4" />
                        <Skeleton className="h-16 w-full" />
                        <div className="flex items-center space-x-6">
                          <Skeleton className="h-8 w-20" />
                          <Skeleton className="h-8 w-16" />
                          <Skeleton className="h-8 w-16" />
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : posts && posts.length > 0 ? (
                filteredPosts.map((post, index) => (
                  <div 
                    key={post.id} 
                    className="animate-fade-in-up border-b border-gray-100 dark:border-slate-700 last:border-b-0" 
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <PostCard post={post} onUpdate={refetch} />
                  </div>
                ))
              ) : (
                <div className="text-center py-16">
                  <div className="mb-8">
                    <div className="w-20 h-20 bg-gradient-to-br from-orange-100 to-red-100 dark:from-slate-700 dark:to-slate-600 rounded-full flex items-center justify-center mx-auto mb-6">
                      <MessageSquare className="h-10 w-10 text-orange-500 dark:text-orange-400" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                      No posts yet
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400 text-lg mb-8 max-w-md mx-auto">
                      Be the first to start a conversation in your community. Share your thoughts, ask questions, or start a discussion.
                    </p>
                    <Button 
                      onClick={handleCreatePost}
                      className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-8 py-3 rounded-xl text-lg font-medium shadow-lg hover:shadow-xl transition-all duration-300"
                    >
                      <Edit3 className="h-5 w-5 mr-3" />
                      Write Your First Post
                    </Button>
                  </div>
                </div>
              )}
            </div>

            {/* Load More Button */}
            {posts && posts.length > 0 && (
              <div className="text-center mt-8">
                <Button 
                  variant="outline" 
                  className="bg-white dark:bg-slate-800 border-gray-200 dark:border-slate-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-700"
                >
                  Load More Posts
                </Button>
              </div>
            )}
          </div>
        </main>
      </div>

    </div>
  );
}
