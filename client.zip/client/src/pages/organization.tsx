import { useEffect, useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/Navigation";
import Sidebar from "@/components/Sidebar";
import PostCard from "@/components/PostCard";
import CreateReviewDialog from "@/components/CreateReviewDialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Building, Users, Star, TrendingUp, Calendar, Filter, ExternalLink, PenSquare, MessageSquare, BarChart3, Edit3, ArrowLeft } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useAuth } from "@/hooks/useAuth.tsx";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { OrganizationWithStats, PostWithDetails } from "@shared/schema";

export default function Organization() {
  const params = useParams();
  const [, setLocation] = useLocation();
  const organizationId = parseInt(params.id as string);
  const { toast } = useToast();
  const { isAuthenticated, isLoading: authLoading, checkAuthAndRedirect } = useAuth();
  const [reviewFilter, setReviewFilter] = useState<string>("all");
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const handleCreatePost = () => {
    setLocation("/create-post");
  };

  useEffect(() => {
    document.title = "Organization - Apocalypse";
  }, []);

  const { data: organization, isLoading: orgLoading, error: orgError } = useQuery<OrganizationWithStats>({
    queryKey: ["/api/organizations", organizationId],
    enabled: !!organizationId,
    retry: (failureCount, error) => {
      if (isUnauthorizedError(error)) {
        checkAuthAndRedirect();
        return false;
      }
      return failureCount < 3;
    },
  });

  const { data: posts = [], isLoading: postsLoading, error: postsError } = useQuery<PostWithDetails[]>({
    queryKey: ["/api/posts", "organization", organizationId],
    queryFn: async () => {
      const response = await fetch(`/api/posts?organizationId=${organizationId}&type=review`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error(`${response.status}: ${response.statusText}`);
      }
      
      return response.json();
    },
    enabled: !!organizationId,
    retry: (failureCount, error) => {
      if (isUnauthorizedError(error)) {
        checkAuthAndRedirect();
        return false;
      }
      return failureCount < 3;
    },
  });

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      checkAuthAndRedirect();
      return;
    }
  }, [isAuthenticated, authLoading, checkAuthAndRedirect]);

  if (orgError || postsError) {
    toast({
      title: "Error",
      description: "Failed to load organization data",
      variant: "destructive",
    });
  }

  if (authLoading || orgLoading) {
    return (
      <div className="min-h-screen bg-white dark:bg-slate-900">
        <Navigation />
        <div className="flex w-full h-screen">
          <aside className={`${sidebarOpen ? 'w-[240px]' : 'w-[60px]'} h-[calc(100vh-4rem)] sticky top-16 bg-white dark:bg-slate-800 border-r border-gray-200 dark:border-slate-700 overflow-y-auto transition-all duration-300 flex-shrink-0`}>
            <div className="p-4 space-y-4">
              {[1,2,3,4].map(i => <Skeleton key={i} className="h-8 w-full" />)}
            </div>
          </aside>
          <main className="flex-1 min-w-0 bg-white dark:bg-slate-900 overflow-y-auto">
            <div className="px-4 sm:px-6 lg:px-8 py-6 w-full">
              {[1,2,3].map(i => <Skeleton key={i} className="h-48 w-full mb-4" />)}
            </div>
          </main>
        </div>
      </div>
    );
  }

  if (!organization) {
    return (
      <div className="min-h-screen bg-white dark:bg-slate-900">
        <Navigation />
        <div className="flex w-full h-screen">
          <aside className={`${sidebarOpen ? 'w-[240px]' : 'w-[60px]'} h-[calc(100vh-4rem)] sticky top-16 bg-white dark:bg-slate-800 border-r border-gray-200 dark:border-slate-700 overflow-y-auto transition-all duration-300 flex-shrink-0`}>
            <Sidebar 
              onCreatePost={handleCreatePost}
              onCreateReview={handleCreatePost}
              onToggleSidebar={toggleSidebar}
              isOpen={sidebarOpen}
            />
          </aside>
          <main className="flex-1 min-w-0 bg-white dark:bg-slate-900 overflow-y-auto">
            <div className="px-4 sm:px-6 lg:px-8 py-6 w-full">
              <div className="text-center py-12">
                <div className="w-20 h-20 bg-gradient-to-br from-orange-400 to-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Building className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                  Organization not found
                </h3>
                <p className="text-gray-600 dark:text-gray-400 text-lg mb-8 max-w-md mx-auto">
                  The organization you're looking for doesn't exist or has been removed.
                </p>
                <Button 
                  onClick={() => setLocation("/organizations")}
                  className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-8 py-3 rounded-xl text-lg font-medium shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  <ArrowLeft className="h-5 w-5 mr-3" />
                  Back to Organizations
                </Button>
              </div>
            </div>
          </main>
        </div>
      </div>
    );
  }

  // Filter posts based on sentiment
  const filteredPosts = posts.filter((post: PostWithDetails) => {
    if (reviewFilter === "all") return true;
    return post.sentiment === reviewFilter;
  });

  return (
    <div className="min-h-screen bg-white dark:bg-slate-900">
      <Navigation />
      
      {/* Main Layout */}
      <div className="flex w-full h-screen">
        {/* Left Sidebar - Fixed position like Blind */}
        <aside className={`${sidebarOpen ? 'w-[240px]' : 'w-[60px]'} h-[calc(100vh-4rem)] sticky top-16 bg-white dark:bg-slate-800 border-r border-gray-200 dark:border-slate-700 overflow-y-auto transition-all duration-300 flex-shrink-0`}>
          <Sidebar 
            onCreatePost={handleCreatePost}
            onCreateReview={handleCreatePost}
            onToggleSidebar={toggleSidebar}
            isOpen={sidebarOpen}
          />
        </aside>

        {/* Sidebar Toggle Button */}
        <button
          onClick={toggleSidebar}
          className="lg:hidden fixed top-20 left-4 z-40 p-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-md shadow-md hover:bg-gray-50 dark:hover:bg-slate-700"
        >
          <svg className="w-5 h-5 text-gray-600 dark:text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>

        {/* Main Content Area */}
        <main className="flex-1 min-w-0 bg-white dark:bg-slate-900 overflow-y-auto">
          <div className="w-full px-2 sm:px-4 lg:px-8 py-6">
            {/* Back Button */}
            <div className="mb-6">
              <Button 
                onClick={() => setLocation("/organizations")}
                variant="ghost"
                className="flex items-center space-x-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to Organizations</span>
              </Button>
            </div>

            {/* Organization Header - Modern Design */}
            <div className="mb-8 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-slate-800 dark:to-slate-700 rounded-2xl p-6 border border-blue-100 dark:border-slate-600 shadow-sm">
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                    <Building className="h-8 w-8 text-white" />
                  </div>
                  <div>
                    <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
                      {organization.name}
                    </h1>
                    <p className="text-gray-600 dark:text-gray-300 text-lg max-w-2xl">
                      {organization.description}
                    </p>
                  </div>
                </div>
                <div className="flex space-x-3">
                  <CreateReviewDialog 
                    organizationId={organization.id} 
                    organizationName={organization.name}
                    trigger={
                      <Button className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg hover:shadow-xl transition-all duration-300">
                        <PenSquare className="h-4 w-4 mr-2" />
                        Write Review
                      </Button>
                    }
                  />
                  {organization.website && (
                    <Button variant="outline" className="flex items-center space-x-2 border-2 border-blue-200 hover:border-blue-300 hover:bg-blue-50 dark:hover:bg-blue-950/20" onClick={() => window.open(organization.website || '', '_blank')}>
                      <ExternalLink className="h-4 w-4" />
                      <span>Visit Website</span>
                    </Button>
                  )}
                </div>
              </div>
              
              {/* Organization Stats */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-6 text-sm text-gray-600 dark:text-gray-400">
                  <div className="flex items-center space-x-2 bg-white/80 dark:bg-slate-700/80 px-3 py-2 rounded-lg">
                    <Users className="h-4 w-4 text-blue-600" />
                    <span className="font-medium">{organization.reviewCount} reviews</span>
                  </div>
                  <div className="flex items-center space-x-2 bg-white/80 dark:bg-slate-700/80 px-3 py-2 rounded-lg">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="font-medium">{organization.averageRating?.toFixed(1) || 0}/5</span>
                  </div>
                  {organization.lastReviewDate && (
                    <div className="flex items-center space-x-2 bg-white/80 dark:bg-slate-700/80 px-3 py-2 rounded-lg">
                      <Calendar className="h-4 w-4 text-green-600" />
                      <span className="font-medium">Last review {formatDistanceToNow(new Date(organization.lastReviewDate))} ago</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Write a Review Section - Modern Floating Style */}
            <div className="mb-8 bg-gradient-to-r from-orange-50 to-red-50 dark:from-slate-800 dark:to-slate-700 rounded-2xl p-6 border border-orange-100 dark:border-slate-600 shadow-sm">
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-red-500 rounded-xl flex items-center justify-center shadow-lg">
                  <Edit3 className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1">
                  <CreateReviewDialog 
                    organizationId={organization.id} 
                    organizationName={organization.name}
                    trigger={
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left text-gray-600 dark:text-gray-300 bg-white/80 dark:bg-slate-700/80 border-gray-200 dark:border-slate-600 hover:bg-white dark:hover:bg-slate-700 rounded-xl h-12 text-base"
                      >
                        Share your experience with {organization.name}...
                      </Button>
                    }
                  />
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex space-x-4">
                  <Button
                    onClick={handleCreatePost}
                    variant="ghost"
                    size="sm"
                    className="text-gray-600 dark:text-gray-400 hover:text-orange-600 dark:hover:text-orange-400 hover:bg-orange-50 dark:hover:bg-slate-700 rounded-lg px-4 py-2"
                  >
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Discussion
                  </Button>
                  <Button
                    onClick={handleCreatePost}
                    variant="ghost"
                    size="sm"
                    className="text-gray-600 dark:text-gray-400 hover:text-orange-600 dark:hover:text-orange-400 hover:bg-orange-50 dark:hover:bg-slate-700 rounded-lg px-4 py-2"
                  >
                    <BarChart3 className="h-4 w-4 mr-2" />
                    Poll
                  </Button>
                </div>
              </div>
            </div>

            {/* Sentiment Analytics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <Card className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200 dark:border-green-800 hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg">
                      <span className="text-2xl">👍</span>
                    </div>
                    <div>
                      <p className="text-sm text-green-600 dark:text-green-400 font-medium">Positive Reviews</p>
                      <p className="text-2xl font-bold text-green-700 dark:text-green-300">
                        {organization.sentimentBreakdown?.positive || 0}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-r from-yellow-50 to-amber-50 dark:from-yellow-900/20 dark:to-amber-900/20 border-yellow-200 dark:border-yellow-800 hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-amber-600 rounded-xl flex items-center justify-center shadow-lg">
                      <span className="text-2xl">😐</span>
                    </div>
                    <div>
                      <p className="text-sm text-yellow-600 dark:text-yellow-400 font-medium">Neutral Reviews</p>
                      <p className="text-2xl font-bold text-yellow-700 dark:text-yellow-300">
                        {organization.sentimentBreakdown?.neutral || 0}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-r from-red-50 to-pink-50 dark:from-red-900/20 dark:to-pink-900/20 border-red-200 dark:border-red-800 hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-pink-600 rounded-xl flex items-center justify-center shadow-lg">
                      <span className="text-2xl">👎</span>
                    </div>
                    <div>
                      <p className="text-sm text-red-600 dark:text-red-400 font-medium">Negative Reviews</p>
                      <p className="text-2xl font-bold text-red-700 dark:text-red-300">
                        {organization.sentimentBreakdown?.negative || 0}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Reviews Section */}
            <div className="space-y-6 w-full">
              {/* Reviews Header */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                    <MessageSquare className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Latest Reviews</h2>
                    <p className="text-gray-600 dark:text-gray-400">See what others are saying about {organization.name}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Filter className="h-4 w-4 text-gray-500" />
                  <Select value={reviewFilter} onValueChange={setReviewFilter}>
                    <SelectTrigger className="w-40 border-2 border-gray-200 dark:border-slate-600">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Reviews</SelectItem>
                      <SelectItem value="positive">Positive</SelectItem>
                      <SelectItem value="neutral">Neutral</SelectItem>
                      <SelectItem value="negative">Negative</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Reviews List */}
              {postsLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="animate-pulse">
                      <div className="flex items-start space-x-4 py-6 border-b border-gray-100 dark:border-slate-700">
                        <Skeleton className="h-10 w-10 rounded-full flex-shrink-0" />
                        <div className="flex-1 space-y-3">
                          <div className="flex items-center space-x-2">
                            <Skeleton className="h-4 w-24" />
                            <Skeleton className="h-3 w-16" />
                          </div>
                          <Skeleton className="h-5 w-3/4" />
                          <Skeleton className="h-16 w-full" />
                          <div className="flex items-center space-x-6">
                            <Skeleton className="h-8 w-20" />
                            <Skeleton className="h-8 w-16" />
                            <Skeleton className="h-8 w-16" />
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : filteredPosts.length > 0 ? (
                <div className="space-y-6">
                  {filteredPosts.map((post: PostWithDetails, index) => (
                    <div 
                      key={post.id} 
                      className="animate-fade-in-up border-b border-gray-100 dark:border-slate-700 last:border-b-0" 
                      style={{ animationDelay: `${index * 50}ms` }}
                    >
                      <PostCard post={post} onUpdate={() => {}} />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-16">
                  <div className="mb-8">
                    <div className="w-20 h-20 bg-gradient-to-br from-blue-100 to-purple-100 dark:from-slate-700 dark:to-slate-600 rounded-full flex items-center justify-center mx-auto mb-6">
                      <MessageSquare className="h-10 w-10 text-blue-500 dark:text-blue-400" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                      {reviewFilter === "all" ? "No reviews yet" : `No ${reviewFilter} reviews`}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400 text-lg mb-8 max-w-md mx-auto">
                      {reviewFilter === "all" 
                        ? `Be the first to share your experience with ${organization.name}!` 
                        : `No ${reviewFilter} reviews found for this organization.`
                      }
                    </p>
                    {reviewFilter === "all" && (
                      <CreateReviewDialog 
                        organizationId={organization.id} 
                        organizationName={organization.name}
                        trigger={
                          <Button 
                            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8 py-3 rounded-xl text-lg font-medium shadow-lg hover:shadow-xl transition-all duration-300"
                          >
                            <PenSquare className="h-5 w-5 mr-3" />
                            Write First Review
                          </Button>
                        }
                      />
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}