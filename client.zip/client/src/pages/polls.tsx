import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/Navigation";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  BarChart3, Clock, Users, CheckCircle2, AlertCircle, 
  TrendingUp, Vote, Plus 
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth.tsx";
import VoteButtons from "@/components/VoteButtons";

interface PollOption {
  id: number;
  text: string;
  voteCount: number;
  isVotedBy?: boolean;
}

interface Poll {
  id: number;
  title: string;
  description?: string;
  author: { firstName?: string; lastName?: string; email: string };
  bowl?: { name: string };
  organization?: { name: string };
  options: PollOption[];
  totalVotes: number;
  allowMultipleChoices: boolean;
  createdAt: string;
  hasVoted?: boolean;
  selectedOptions?: number[];
  upvotes: number;
  downvotes: number;
  userVote?: { id: number; createdAt: Date | null; userId: string; targetId: number; targetType: string; voteType: string };
}

export default function Polls() {
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const [selectedOptions, setSelectedOptions] = useState<{[pollId: number]: number[]}>({});
  const [sortBy, setSortBy] = useState<'hot' | 'recent'>('hot');


  // Fetch polls from API
  const { data: polls = [], isLoading: pollsLoading, refetch } = useQuery<Poll[]>({
    queryKey: ["polls"],
    queryFn: async () => {
      const response = await fetch("/api/polls", {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error(`${response.status}: ${response.statusText}`);
      }
      
      return response.json();
    },
    enabled: isAuthenticated,
  });

  useEffect(() => {
    document.title = "Polls - Apocalypse";
  }, []);

  const handleVote = (pollId: number, optionId: number, allowMultiple: boolean) => {
    setSelectedOptions(prev => {
      const current = prev[pollId] || [];
      
      if (allowMultiple) {
        // Toggle option for multiple choice
        const newSelection = current.includes(optionId)
          ? current.filter(id => id !== optionId)
          : [...current, optionId];
        return { ...prev, [pollId]: newSelection };
      } else {
        // Single choice
        return { ...prev, [pollId]: [optionId] };
      }
    });
  };

  const submitVote = async (pollId: number) => {
    const selectedOptionIds = selectedOptions[pollId];
    if (!selectedOptionIds || selectedOptionIds.length === 0) return;

    try {
      const response = await fetch(`/api/polls/${pollId}/vote`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ optionIds: selectedOptionIds }),
      });

      if (response.ok) {
        // Clear selection and refetch polls
        setSelectedOptions(prev => {
          const newState = { ...prev };
          delete newState[pollId];
          return newState;
        });
        refetch();
      }
    } catch (error) {
      console.error('Error voting on poll:', error);
    }
  };

  const [sidebarOpen, setSidebarOpen] = useState(true);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const handleCreatePost = () => {
    // Navigate to create post page
    window.location.href = '/create-post';
  };

  const truncateContent = (content: string, maxLength: number = 200) => {
    if (content.length <= maxLength) return content;
    return content.substring(0, maxLength).trim() + '...';
  };

  // Sort polls based on selected criteria
  const sortedPolls = [...polls].sort((a, b) => {
    if (sortBy === 'recent') {
      // Sort by creation date (newest first)
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    } else {
      // Sort by hot (total votes + recency factor)
      const aScore = a.totalVotes + (Date.now() - new Date(a.createdAt).getTime()) / (1000 * 60 * 60 * 24); // votes + days since creation
      const bScore = b.totalVotes + (Date.now() - new Date(b.createdAt).getTime()) / (1000 * 60 * 60 * 24);
      return bScore - aScore;
    }
  });

  const handleCreatePoll = () => {
    window.location.href = '/create-post?type=poll';
  };



  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
        <Navigation />
        {/* Main Layout */}
        <div className="flex w-full h-screen">
          {/* Left Sidebar - Fixed position like Blind */}
          <aside className={`${sidebarOpen ? 'w-[240px]' : 'w-[60px]'} h-[calc(100vh-4rem)] sticky top-16 bg-white dark:bg-slate-800 border-r border-gray-200 dark:border-slate-700 overflow-y-auto transition-all duration-300 flex-shrink-0`}>
            <div className="p-4 space-y-4">
              {[1,2,3,4].map(i => <Skeleton key={i} className="h-8 w-full" />)}
            </div>
          </aside>

          {/* Main Content Area */}
          <main className="flex-1 min-w-0 bg-gray-50 dark:bg-slate-900 overflow-y-auto">
            <div className="px-4 sm:px-6 lg:px-8 py-6 w-full">
              {[1,2,3].map(i => <Skeleton key={i} className="h-48 w-full mb-4" />)}
            </div>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-orange-50/30 dark:from-slate-900 dark:via-slate-800 dark:to-orange-900/10">
      <Navigation />
      {/* Main Layout */}
      <div className="flex w-full h-screen">
        {/* Left Sidebar - Fixed position like Blind */}
        <aside className={`${sidebarOpen ? 'w-[240px]' : 'w-[60px]'} h-[calc(100vh-4rem)] sticky top-16 bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm border-r border-gray-200 dark:border-slate-700 overflow-y-auto transition-all duration-300 flex-shrink-0`}>
          <Sidebar 
            onCreatePost={handleCreatePost} 
            onCreateReview={handleCreatePost}
            onToggleSidebar={toggleSidebar}
            isOpen={sidebarOpen}
          />
        </aside>

        {/* Sidebar Toggle Button */}
        <button
          onClick={toggleSidebar}
          className="lg:hidden fixed top-20 left-4 z-40 p-2 bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm border border-gray-200 dark:border-slate-700 rounded-lg shadow-lg hover:bg-gray-50 dark:hover:bg-slate-700"
        >
          <svg className="w-5 h-5 text-gray-600 dark:text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>

        {/* Main Content Area */}
        <main className="flex-1 min-w-0 bg-transparent overflow-y-auto">
          <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
            {/* Header Section */}
            <div className="mb-8">
              <div className="inline-flex items-center px-4 py-2 rounded-full bg-gradient-to-r from-blue-100 to-purple-100 dark:from-blue-900/30 dark:to-purple-900/30 text-blue-700 dark:text-blue-300 text-sm font-medium mb-4">
                <BarChart3 className="h-4 w-4 mr-2" />
                Community Polls
              </div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-gray-900 via-blue-600 to-purple-600 dark:from-white dark:via-blue-300 dark:to-purple-300 bg-clip-text text-transparent mb-3">
                Share Your Voice
              </h1>
              <p className="text-gray-600 dark:text-gray-400 text-lg max-w-2xl">
                Create polls, vote on topics, and see what the community thinks about important issues
              </p>
            </div>

            {/* Action Bar */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-4">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Sort by:</span>
                <div className="flex space-x-2">
                  <Button 
                    variant={sortBy === 'hot' ? 'default' : 'outline'} 
                    size="sm" 
                    onClick={() => setSortBy('hot')}
                    className={sortBy === 'hot' 
                      ? 'bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-md' 
                      : 'border-gray-200 dark:border-slate-700 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-slate-800'
                    }
                  >
                    <TrendingUp className="h-3 w-3 mr-1" />
                    Hot
                  </Button>
                  <Button 
                    variant={sortBy === 'recent' ? 'default' : 'outline'} 
                    size="sm" 
                    onClick={() => setSortBy('recent')}
                    className={sortBy === 'recent' 
                      ? 'bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white shadow-md' 
                      : 'border-gray-200 dark:border-slate-700 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-slate-800'
                    }
                  >
                    <Clock className="h-3 w-3 mr-1" />
                    Recent
                  </Button>
                </div>
              </div>
              
              <Button 
                onClick={handleCreatePoll}
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white shadow-lg hover:shadow-xl"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Poll
              </Button>
            </div>

            {/* Polls List */}
            <div className="space-y-6">
              {sortedPolls.length === 0 ? (
                <div className="text-center py-16">
                  <div className="w-20 h-20 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-6">
                    <BarChart3 className="h-10 w-10 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">No polls yet</h3>
                  <p className="text-gray-600 dark:text-gray-400 text-lg mb-6 max-w-md mx-auto">
                    Be the first to create a poll and see what the community thinks!
                  </p>
                  <Button 
                    onClick={handleCreatePoll}
                    className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8 py-3 rounded-xl font-medium shadow-lg hover:shadow-xl"
                  >
                    <Plus className="h-5 w-5 mr-2" />
                    Create Poll
                  </Button>
                </div>
              ) : (
                sortedPolls.map((poll: Poll) => {
                  const userSelection = selectedOptions[poll.id] || [];
                  const showVoteButton = !poll.hasVoted && userSelection.length > 0;
                
                return (
                  <div key={poll.id} className="group relative overflow-hidden bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl p-6 hover:shadow-xl hover:border-orange-300 dark:hover:border-orange-500 transition-all duration-300 hover:-translate-y-1 cursor-pointer" onClick={() => window.location.href = `/poll?id=${poll.id}`}>
                    {/* Gradient background overlay */}
                    <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 via-transparent to-purple-50/30 dark:from-blue-900/10 dark:via-transparent dark:to-purple-900/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    
                    {/* Subtle pattern overlay */}
                    <div className="absolute inset-0 opacity-5 bg-gradient-to-br from-blue-400 to-purple-600"></div>
                    
                    <div className="relative z-10">
                      {/* Poll Header */}
                      <div className="mb-6">
                        <div className="flex items-start space-x-4 mb-4">
                          {/* Vote Buttons */}
                          <div className="transform hover:scale-105 transition-transform duration-300" onClick={(e) => e.stopPropagation()}>
                            <VoteButtons 
                              targetId={poll.id}
                              targetType="poll"
                              upvotes={poll.upvotes}
                              downvotes={poll.downvotes}
                              userVote={poll.userVote}
                              onUpdate={refetch}
                            />
                          </div>
                          
                          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                            <Vote className="h-6 w-6 text-white" />
                          </div>
                          <div className="flex-1">
                            {/* Poll title moved above metadata */}
                            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
                              {poll.title}
                            </h3>
                            
                            {/* Metadata moved below title */}
                            <div className="flex items-center space-x-2 mb-4">
                              <span className="text-sm text-muted-foreground">
                                Posted by
                              </span>
                              <span className="text-sm font-medium text-reddit-orange hover:text-reddit-orange/80 hover:underline cursor-pointer">
                                {poll.author.firstName || poll.author.email.split('@')[0]}
                              </span>
                              <span className="text-sm text-muted-foreground">
                                about {Math.floor((Date.now() - new Date(poll.createdAt).getTime()) / (1000 * 60 * 60))} hours ago
                              </span>
                              {poll.organization && (
                                <>
                                  <span className="text-sm text-muted-foreground">in</span>
                                  <span className="text-sm font-medium text-professional-blue hover:underline cursor-pointer">
                                    {poll.organization.name}
                                  </span>
                                </>
                              )}
                              {poll.bowl && (
                                <>
                                  <span className="text-sm text-muted-foreground">in</span>
                                  <span className="text-sm font-medium text-reddit-orange hover:underline cursor-pointer">
                                    {poll.bowl.name}
                                  </span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-2">
                            {poll.hasVoted ? (
                              <>
                                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300">
                                  ✓ Voted
                                </span>
                                <span className="text-sm text-gray-500">
                                  {poll.totalVotes.toLocaleString()} Participants
                                </span>
                              </>
                            ) : (
                              <>
                                <span className="text-sm text-gray-500">
                                  {poll.totalVotes.toLocaleString()} Participants
                                </span>
                                <span className="text-sm text-gray-500">
                                  {poll.allowMultipleChoices ? 'Select multiple answers' : 'Select only one answer'}
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                        
                        {poll.description && (
                          <div className="text-gray-600 dark:text-gray-300 text-sm mb-3">
                            <div className="whitespace-pre-wrap">
                              {truncateContent(poll.description)}
                            </div>
                            {poll.description.length > 200 && (
                              <Button
                                variant="link"
                                className="p-0 h-auto text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium text-sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  window.location.href = `/poll?id=${poll.id}`;
                                }}
                              >
                                Read more
                              </Button>
                            )}
                          </div>
                        )}
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <div className="flex items-center space-x-1">
                              <Users className="h-4 w-4" />
                              <span>{poll.totalVotes} Votes</span>
                            </div>
                            {poll.allowMultipleChoices && (
                              <span className="text-xs bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 px-2 py-1 rounded">
                                Multiple selections allowed
                              </span>
                            )}
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              window.location.href = `/poll?id=${poll.id}`;
                            }}
                            className="text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-800 hover:bg-blue-50 dark:hover:bg-blue-950/20"
                          >
                            View Poll
                          </Button>
                        </div>
                      </div>

                      {/* Poll Options */}
                      <div className="space-y-3 mb-6">
                        {poll.options.map((option) => {
                          const isSelected = userSelection.includes(option.id);
                          const isVotedOption = poll.hasVoted && poll.selectedOptions?.includes(option.id);
                          const showResults = poll.hasVoted;
                          const percentage = poll.totalVotes > 0 ? Math.round((option.voteCount / poll.totalVotes) * 100) : 0;
                          
                          return (
                            <div key={option.id} className="relative">
                              <div
                                className={`p-4 rounded-xl border cursor-pointer transition-all duration-200 ${
                                  isSelected
                                    ? "border-blue-500 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20"
                                    : isVotedOption
                                    ? "border-green-500 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20"
                                    : "border-gray-200 dark:border-slate-600 hover:border-blue-300 dark:hover:border-blue-500"
                                } ${!poll.hasVoted ? "hover:bg-gray-50 dark:hover:bg-slate-700" : ""}`}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  !poll.hasVoted && handleVote(poll.id, option.id, poll.allowMultipleChoices);
                                }}
                              >
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center space-x-3">
                                    {!poll.hasVoted ? (
                                      <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                                        isSelected
                                          ? "border-blue-500 bg-blue-500"
                                          : "border-gray-300 dark:border-slate-500"
                                      }`}>
                                        {isSelected && (
                                          <CheckCircle2 className="h-3 w-3 text-white" />
                                        )}
                                      </div>
                                    ) : (
                                      <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                                        isVotedOption
                                          ? "border-green-500 bg-green-500"
                                          : "border-gray-300 dark:border-slate-500"
                                      }`}>
                                        {isVotedOption && (
                                          <CheckCircle2 className="h-3 w-3 text-white" />
                                        )}
                                      </div>
                                    )}
                                    <span className="text-sm font-medium text-gray-900 dark:text-white">
                                      {option.text}
                                    </span>
                                  </div>
                                  
                                  {showResults && (
                                    <div className="flex items-center space-x-2">
                                      <span className="text-sm font-bold text-gray-900 dark:text-white">
                                        {percentage}%
                                      </span>
                                      <span className="text-xs text-gray-500">
                                        ({option.voteCount.toLocaleString()})
                                      </span>
                                    </div>
                                  )}
                                </div>
                                
                                {showResults && (
                                  <div className="mt-3">
                                    <div className="w-full bg-gray-200 dark:bg-slate-700 rounded-full h-3 overflow-hidden">
                                      <div 
                                        className={`h-full rounded-full transition-all duration-500 ${
                                          isVotedOption 
                                            ? 'bg-gradient-to-r from-green-500 to-emerald-500' 
                                            : 'bg-gradient-to-r from-blue-500 to-purple-500'
                                        }`}
                                        style={{ width: `${percentage}%` }}
                                      />
                                    </div>
                                  </div>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {/* Vote Button */}
                      {showVoteButton && (
                        <div className="flex justify-center" onClick={(e) => e.stopPropagation()}>
                          <Button 
                            onClick={() => submitVote(poll.id)}
                            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8 py-3 rounded-xl font-medium shadow-lg hover:shadow-xl"
                          >
                            Vote
                          </Button>
                        </div>
                      )}

                      {poll.hasVoted && (
                        <div className="text-center">
                          <Button variant="outline" disabled>
                            View Result
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}