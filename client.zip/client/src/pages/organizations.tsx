import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import Navigation from "@/components/Navigation";
import CreateOrganizationDialog from "@/components/CreateOrganizationDialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Building, Plus, Users, Star, ThumbsUp, ThumbsDown, TrendingUp, TrendingDown } from "lucide-react";
import { useAuth } from "@/hooks/useAuth.tsx";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { OrganizationWithStats } from "@shared/schema";

export default function Organizations() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading: authLoading, checkAuthAndRedirect } = useAuth();

  useEffect(() => {
    document.title = "Organizations - Apocalypse";
  }, []);

  const { data: organizations = [], isLoading, error } = useQuery<OrganizationWithStats[]>({
    queryKey: ["/api/organizations"],
    retry: (failureCount, error) => {
      if (isUnauthorizedError(error)) {
        checkAuthAndRedirect();
        return false;
      }
      return failureCount < 3;
    },
  });

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      checkAuthAndRedirect();
      return;
    }
  }, [isAuthenticated, authLoading, checkAuthAndRedirect]);

  if (error) {
    toast({
      title: "Error",
      description: "Failed to load organizations",
      variant: "destructive",
    });
  }

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-4 w-96" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Skeleton key={i} className="h-64 rounded-2xl" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Calculate trust percentage based on sentiment breakdown
  const calculateTrustPercentage = (org: OrganizationWithStats) => {
    if (!org.sentimentBreakdown) return 50;
    const total = (org.sentimentBreakdown.positive || 0) + (org.sentimentBreakdown.neutral || 0) + (org.sentimentBreakdown.negative || 0);
    if (total === 0) return 50;
    const positiveWeight = (org.sentimentBreakdown.positive || 0) * 1;
    const neutralWeight = (org.sentimentBreakdown.neutral || 0) * 0.5;
    const negativeWeight = (org.sentimentBreakdown.negative || 0) * 0;
    return Math.round(((positiveWeight + neutralWeight + negativeWeight) / total) * 100);
  };

  // Get trust status based on percentage
  const getTrustStatus = (percentage: number) => {
    if (percentage >= 70) return { status: "Insulated", color: "text-green-600", bgColor: "bg-green-100" };
    if (percentage >= 40) return { status: "Neutral", color: "text-yellow-600", bgColor: "bg-yellow-100" };
    return { status: "At Risk", color: "text-red-600", bgColor: "bg-red-100" };
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
              Organizations
            </h1>
            <p className="text-gray-600 dark:text-gray-300 text-lg">
              Discover and evaluate companies across various industries
            </p>
          </div>
          <CreateOrganizationDialog />
        </div>

        {/* Organizations Grid */}
        {organizations.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {organizations.map((org) => {
              const trustPercentage = calculateTrustPercentage(org);
              const trustStatus = getTrustStatus(trustPercentage);
              
              return (
                <Link key={org.id} href={`/organizations/${org.id}`}>
                  <Card className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl transition-all duration-300 cursor-pointer rounded-2xl overflow-hidden group">
                    <div className="p-6">
                      {/* Organization Header */}
                      <div className="flex items-start justify-between mb-6">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                            <Building className="h-6 w-6 text-white" />
                          </div>
                          <div>
                            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-1">
                              {org.name}
                            </h3>
                            <p className="text-sm text-gray-600 dark:text-gray-300 line-clamp-2">
                              {org.description}
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Trust Percentage Display */}
                      <div className="mb-6">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-2">
                            <TrendingUp className="h-4 w-4 text-blue-600" />
                            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                              Trust Score
                            </span>
                          </div>
                          <div className={`px-3 py-1 rounded-full text-xs font-medium ${trustStatus.bgColor} ${trustStatus.color}`}>
                            {trustStatus.status}
                          </div>
                        </div>
                        
                        {/* Progress Bar */}
                        <div className="relative">
                          <div className="w-full h-3 bg-gray-200 dark:bg-slate-700 rounded-full overflow-hidden">
                            <div 
                              className={`h-full transition-all duration-500 ${
                                trustPercentage >= 70 ? 'bg-gradient-to-r from-green-400 to-green-600' :
                                trustPercentage >= 40 ? 'bg-gradient-to-r from-yellow-400 to-yellow-600' :
                                'bg-gradient-to-r from-red-400 to-red-600'
                              }`}
                              style={{ width: `${trustPercentage}%` }}
                            />
                          </div>
                          <div className="absolute inset-0 flex items-center justify-center">
                            <span className="text-lg font-bold text-gray-900 dark:text-white drop-shadow-sm">
                              {trustPercentage}%
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Stats Row */}
                      <div className="flex items-center justify-between mb-6 text-sm">
                        <div className="flex items-center space-x-2">
                          <Users className="h-4 w-4 text-blue-600" />
                          <span className="text-gray-700 dark:text-gray-300 font-medium">
                            {org.reviewCount} reviews
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <span className="font-bold text-gray-900 dark:text-white">
                            {org.averageRating?.toFixed(1) || 0}/5
                          </span>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex space-x-3">
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1 border-2 border-green-300 text-green-700 hover:bg-green-50 dark:border-green-600 dark:text-green-400 dark:hover:bg-green-900/20 font-medium"
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            // TODO: Implement trust voting
                          }}
                        >
                          <ThumbsUp className="h-4 w-4 mr-2" />
                          Buy Trust
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1 border-2 border-red-300 text-red-700 hover:bg-red-50 dark:border-red-600 dark:text-red-400 dark:hover:bg-red-900/20 font-medium"
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            // TODO: Implement distrust voting
                          }}
                        >
                          <ThumbsDown className="h-4 w-4 mr-2" />
                          Buy Distrust
                        </Button>
                      </div>
                    </div>
                  </Card>
                </Link>
              );
            })}
          </div>
        ) : (
          <Card className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm border-0 shadow-xl">
            <CardContent className="py-16">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                  <Building className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                  No organizations found
                </h3>
                <p className="text-gray-600 dark:text-gray-400 text-lg mb-8 max-w-md mx-auto">
                  Be the first to add an organization to the platform and start building trust scores.
                </p>
                <CreateOrganizationDialog trigger={
                  <Button className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8 py-3 rounded-xl text-lg font-medium shadow-lg hover:shadow-xl transition-all duration-300">
                    <Plus className="h-5 w-5 mr-3" />
                    Add First Organization
                  </Button>
                } />
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}