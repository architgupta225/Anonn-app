import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/Navigation";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  TrendingUp, Clock, Users, MessageSquare, 
  ThumbsUp, Eye, Zap, Flame, BarChart3 
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import VoteButtons from "@/components/VoteButtons";
import { formatDistanceToNow } from "date-fns";

interface TrendingPost {
  id: number;
  title: string;
  content: string;
  type: string;
  sentiment?: string;
  isAnonymous: boolean;
  upvotes: number;
  downvotes: number;
  commentCount: number;
  createdAt: string;
  author: { 
    id: string; 
    firstName?: string; 
    lastName?: string; 
    email: string;
    karma: number;
  };
  organization?: { id: number; name: string };
  bowl?: { id: number; name: string };
  userVote?: { id: number; createdAt: Date | null; userId: string; targetId: number; targetType: string; voteType: string };
  trendingScore?: number;
}

interface TrendingPoll {
  id: number;
  title: string;
  description?: string;
  author: { firstName?: string; lastName?: string; email: string };
  bowl?: { name: string };
  organization?: { name: string };
  options: Array<{ id: number; text: string; voteCount: number }>;
  totalVotes: number;
  allowMultipleChoices: boolean;
  createdAt: string;
  upvotes: number;
  downvotes: number;
  userVote?: { id: number; createdAt: Date | null; userId: string; targetId: number; targetType: string; voteType: string };
  trendingScore?: number;
}

export default function Trending() {
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [timeFilter, setTimeFilter] = useState<'today' | 'week' | 'month'>('today');

  // Fetch trending posts
  const { data: trendingPosts = [], isLoading: postsLoading, refetch: refetchPosts } = useQuery<TrendingPost[]>({
    queryKey: ["trending-posts", timeFilter],
    queryFn: async () => {
      const response = await fetch(`/api/posts?trending=true&time=${timeFilter}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error(`${response.status}: ${response.statusText}`);
      }
      
      return response.json();
    },
    enabled: isAuthenticated,
  });

  // Fetch trending polls
  const { data: trendingPolls = [], isLoading: pollsLoading, refetch: refetchPolls } = useQuery<TrendingPoll[]>({
    queryKey: ["trending-polls", timeFilter],
    queryFn: async () => {
      const response = await fetch(`/api/polls?trending=true&time=${timeFilter}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error(`${response.status}: ${response.statusText}`);
      }
      
      return response.json();
    },
    enabled: isAuthenticated,
  });

  useEffect(() => {
    document.title = "Trending - Apocalypse";
  }, []);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const handleCreatePost = () => {
    window.location.href = '/create-post';
  };



  const getAuthorDisplay = (author: any) => {
    if (author.firstName && author.lastName) {
      return `${author.firstName} ${author.lastName}`;
    }
    return author.email.split('@')[0];
  };

  const truncateContent = (content: string, maxLength: number = 200) => {
    if (content.length <= maxLength) return content;
    return content.substring(0, maxLength) + '...';
  };

  const getTrendingScore = (item: TrendingPost | TrendingPoll) => {
    const baseScore = item.trendingScore || 0;
    const score = Math.floor(baseScore);
    
    if (score >= 1000) return `${(score / 1000).toFixed(1)}k`;
    return score.toString();
  };

  const getTimeFilterLabel = () => {
    switch (timeFilter) {
      case 'today': return 'Today';
      case 'week': return 'This Week';
      case 'month': return 'This Month';
      default: return 'Today';
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex justify-center items-center h-64">
            <div className="text-center animate-pulse">
              <Skeleton className="h-12 w-48 mx-auto mb-4" />
              <Skeleton className="h-6 w-64 mx-auto" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-slate-900">
      <Navigation />
      {/* Main Layout */}
      <div className="flex w-full h-screen">
        {/* Left Sidebar - Fixed position like Blind */}
        <aside className={`${sidebarOpen ? 'w-[240px]' : 'w-[60px]'} h-[calc(100vh-4rem)] sticky top-16 bg-white dark:bg-slate-800 border-r border-gray-200 dark:border-slate-700 overflow-y-auto transition-all duration-300 flex-shrink-0`}>
          <Sidebar 
            onCreatePost={handleCreatePost} 
            onCreateReview={handleCreatePost}
            onToggleSidebar={toggleSidebar}
            isOpen={sidebarOpen}
          />
        </aside>

        {/* Sidebar Toggle Button */}
        <button
          onClick={toggleSidebar}
          className="lg:hidden fixed top-20 left-4 z-50 p-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-md shadow-md hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>

        {/* Main Content */}
        <main className="flex-1 min-w-0 bg-white dark:bg-slate-900 overflow-y-auto">
          <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
            {/* Header */}
            <div className="mb-8">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-red-500 rounded-xl flex items-center justify-center shadow-lg">
                  <TrendingUp className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                    Trending
                  </h1>
                  <p className="text-gray-600 dark:text-gray-400">
                    What's hot and gaining momentum in the community
                  </p>
                </div>
              </div>

              {/* Time Filter */}
              <div className="flex items-center space-x-2">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Time:</span>
                <div className="flex space-x-2">
                  <Button 
                    variant={timeFilter === 'today' ? 'default' : 'outline'} 
                    size="sm" 
                    onClick={() => setTimeFilter('today')}
                    className={timeFilter === 'today' 
                      ? 'bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-md' 
                      : 'border-gray-200 dark:border-slate-700 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-slate-800'
                    }
                  >
                    Today
                  </Button>
                  <Button 
                    variant={timeFilter === 'week' ? 'default' : 'outline'} 
                    size="sm" 
                    onClick={() => setTimeFilter('week')}
                    className={timeFilter === 'week' 
                      ? 'bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-md' 
                      : 'border-gray-200 dark:border-slate-700 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-slate-800'
                    }
                  >
                    Week
                  </Button>
                  <Button 
                    variant={timeFilter === 'month' ? 'default' : 'outline'} 
                    size="sm" 
                    onClick={() => setTimeFilter('month')}
                    className={timeFilter === 'month' 
                      ? 'bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-md' 
                      : 'border-gray-200 dark:border-slate-700 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-slate-800'
                    }
                  >
                    Month
                  </Button>
                </div>
              </div>
            </div>

            {/* Trending Posts Section */}
            <div className="mb-12">
              <div className="flex items-center space-x-2 mb-6">
                <Flame className="h-5 w-5 text-orange-500" />
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                  Trending Posts
                </h2>
                <Badge className="bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300">
                  {trendingPosts.length} posts
                </Badge>
              </div>

              {postsLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <Card key={i} className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700">
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <Skeleton className="h-8 w-8 rounded" />
                          <div className="flex-1 space-y-2">
                            <Skeleton className="h-4 w-3/4" />
                            <Skeleton className="h-4 w-1/2" />
                            <Skeleton className="h-4 w-2/3" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : trendingPosts.length === 0 ? (
                <Card className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700">
                  <CardContent className="p-8 text-center">
                    <Flame className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                      No trending posts yet
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      Trending posts will appear here based on engagement and activity.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {trendingPosts.map((post, index) => (
                    <Card key={post.id} className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          {/* Trending Rank */}
                          <div className="flex flex-col items-center space-y-2">
                            <div className="w-8 h-8 bg-gradient-to-br from-orange-400 to-red-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                              {index + 1}
                            </div>
                            <div className="text-xs text-gray-500 font-medium">
                              {getTrendingScore(post)}
                            </div>
                          </div>

                          {/* Vote Buttons */}
                          <div className="transform hover:scale-105 transition-transform duration-300">
                            <VoteButtons 
                              targetId={post.id}
                              targetType="post"
                              upvotes={post.upvotes}
                              downvotes={post.downvotes}
                              userVote={post.userVote}
                              onUpdate={refetchPosts}
                            />
                          </div>

                          <div className="flex-1">
                            {/* Post Header */}
                            <div className="flex items-center space-x-2 mb-3">
                              <Badge className="bg-gradient-to-r from-blue-500 to-purple-600 text-white text-xs px-3 py-1">
                                {post.type === 'review' ? 'Discussion' : post.type.charAt(0).toUpperCase() + post.type.slice(1)}
                              </Badge>
                              <span className="text-sm text-gray-500">
                                by {getAuthorDisplay(post.author)}
                              </span>
                              <span className="text-sm text-gray-500">
                                {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
                              </span>
                            </div>

                            {/* Post Title */}
                            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                              {post.title}
                            </h3>

                            {/* Post Content */}
                            <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">
                              {truncateContent(post.content)}
                            </p>

                            {/* Post Stats */}
                            <div className="flex items-center space-x-4 text-sm text-gray-500">
                              <div className="flex items-center space-x-1">
                                <MessageSquare className="h-4 w-4" />
                                <span>{post.commentCount} comments</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <ThumbsUp className="h-4 w-4" />
                                <span>{post.upvotes - post.downvotes} points</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <TrendingUp className="h-4 w-4" />
                                <span>Trending</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>

            {/* Trending Polls Section */}
            <div className="mb-12">
              <div className="flex items-center space-x-2 mb-6">
                <Zap className="h-5 w-5 text-blue-500" />
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                  Trending Polls
                </h2>
                <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300">
                  {trendingPolls.length} polls
                </Badge>
              </div>

              {pollsLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <Card key={i} className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700">
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <Skeleton className="h-8 w-8 rounded" />
                          <div className="flex-1 space-y-2">
                            <Skeleton className="h-4 w-3/4" />
                            <Skeleton className="h-4 w-1/2" />
                            <Skeleton className="h-4 w-2/3" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : trendingPolls.length === 0 ? (
                <Card className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700">
                  <CardContent className="p-8 text-center">
                    <Zap className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                      No trending polls yet
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      Trending polls will appear here based on engagement and activity.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {trendingPolls.map((poll, index) => (
                    <Card key={poll.id} className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          {/* Trending Rank */}
                          <div className="flex flex-col items-center space-y-2">
                            <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                              {index + 1}
                            </div>
                            <div className="text-xs text-gray-500 font-medium">
                              {getTrendingScore(poll)}
                            </div>
                          </div>

                          {/* Vote Buttons */}
                          <div className="transform hover:scale-105 transition-transform duration-300">
                            <VoteButtons 
                              targetId={poll.id}
                              targetType="poll"
                              upvotes={poll.upvotes}
                              downvotes={poll.downvotes}
                              userVote={poll.userVote}
                              onUpdate={refetchPolls}
                            />
                          </div>

                          <div className="flex-1">
                            {/* Poll Header */}
                            <div className="flex items-center space-x-2 mb-3">
                              <Badge className="bg-gradient-to-r from-blue-500 to-purple-600 text-white text-xs px-3 py-1">
                                <BarChart3 className="w-3 h-3 mr-1" />
                                Poll
                              </Badge>
                              <span className="text-sm text-gray-500">
                                by {getAuthorDisplay(poll.author)}
                              </span>
                              <span className="text-sm text-gray-500">
                                {formatDistanceToNow(new Date(poll.createdAt), { addSuffix: true })}
                              </span>
                            </div>

                            {/* Poll Title */}
                            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                              {poll.title}
                            </h3>

                            {/* Poll Description */}
                            {poll.description && (
                              <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">
                                {truncateContent(poll.description)}
                              </p>
                            )}

                            {/* Poll Stats */}
                            <div className="flex items-center space-x-4 text-sm text-gray-500">
                              <div className="flex items-center space-x-1">
                                <Users className="h-4 w-4" />
                                <span>{poll.totalVotes} votes</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <ThumbsUp className="h-4 w-4" />
                                <span>{poll.upvotes - poll.downvotes} points</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <TrendingUp className="h-4 w-4" />
                                <span>Trending</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
} 