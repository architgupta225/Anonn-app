import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/Navigation";
import PostCard from "@/components/PostCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { User, Calendar, TrendingUp, MessageSquare, Star, Award } from "lucide-react";
import { useAuth } from "@/hooks/useAuth.tsx";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { PostWithDetails, Bowl, BowlMembership } from "@shared/schema";

export default function Profile() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();

  const { data: userPosts, isLoading: postsLoading, error: postsError } = useQuery<PostWithDetails[]>({
    queryKey: ["/api/posts", "user"],
    queryFn: async () => {
      const response = await fetch("/api/posts", {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error(`${response.status}: ${response.statusText}`);
      }
      
      const allPosts = await response.json();
      // Filter posts by current user
      return allPosts.filter((post: PostWithDetails) => post.authorId === user?.id);
    },
    enabled: !!user,
    retry: false,
  });

  const { data: userBowls, isLoading: bowlsLoading, error: bowlsError } = useQuery<(BowlMembership & { bowl: Bowl })[]>({
    queryKey: ["/api/user/bowls"],
    enabled: isAuthenticated,
    retry: false,
  });

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  useEffect(() => {
    if ((postsError && isUnauthorizedError(postsError as Error)) || 
        (bowlsError && isUnauthorizedError(bowlsError as Error))) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [postsError, bowlsError, toast]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Skeleton className="h-64 w-full mb-8" />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-64 w-full" />
              ))}
            </div>
            <div>
              <Skeleton className="h-96 w-full" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center py-12">
            <User className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-2">
              Profile not found
            </h2>
            <p className="text-gray-600 dark:text-gray-300">
              Unable to load your profile. Please try again.
            </p>
          </div>
        </div>
      </div>
    );
  }

  const getKarmaColor = (karma: number) => {
    if (karma >= 1000) return "text-positive";
    if (karma >= 500) return "text-professional-blue";
    if (karma >= 0) return "text-neutral";
    return "text-negative";
  };

  const getKarmaBadgeVariant = (karma: number) => {
    if (karma >= 1000) return "bg-positive";
    if (karma >= 500) return "bg-professional-blue";
    if (karma >= 0) return "bg-neutral";
    return "bg-negative";
  };

  const reviewPosts = userPosts?.filter(post => post.type === 'review') || [];
  const discussionPosts = userPosts?.filter(post => post.type === 'discussion') || [];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Profile Header */}
        <Card className="mb-8 bg-white dark:bg-slate-800 border-gray-200 dark:border-slate-700">
          <CardContent className="p-8">
            <div className="flex items-start space-x-6">
              <div className="w-24 h-24 rounded-full overflow-hidden">
                {user.profileImageUrl ? (
                  <img 
                    src={user.profileImageUrl} 
                    alt="Profile" 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-professional-blue flex items-center justify-center">
                    <User className="h-12 w-12 text-white" />
                  </div>
                )}
              </div>
              
              <div className="flex-1">
                <div className="flex items-center space-x-4 mb-3">
                  <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                    {user.firstName && user.lastName 
                      ? `${user.firstName} ${user.lastName}`
                      : user.email?.split('@')[0] || 'Anonymous User'
                    }
                  </h1>
                  <Badge className={`text-white ${getKarmaBadgeVariant(user.karma)} bg-current`}>
                    <TrendingUp className="h-3 w-3 mr-1" />
                    {user.karma} karma
                  </Badge>
                </div>
                
                <div className="flex items-center space-x-6 text-sm text-gray-500 dark:text-gray-400 mb-4">
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-4 w-4" />
                    <span>
                      Joined {new Date(user.createdAt || '').toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'long'
                      })}
                    </span>
                  </div>
                  {user.email && (
                    <div className="flex items-center space-x-1">
                      <span>{user.email}</span>
                    </div>
                  )}
                </div>

                <div className="flex items-center space-x-6 text-sm">
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 text-reddit-orange" />
                    <span className="text-gray-700 dark:text-gray-300">
                      {reviewPosts.length} reviews
                    </span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <MessageSquare className="h-4 w-4 text-professional-blue" />
                    <span className="text-gray-700 dark:text-gray-300">
                      {discussionPosts.length} discussions
                    </span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Award className="h-4 w-4 text-neutral" />
                    <span className="text-gray-700 dark:text-gray-300">
                      {userBowls?.length || 0} bowls
                    </span>
                  </div>
                </div>
              </div>
              
              <Button 
                onClick={() => window.location.href = '/api/logout'}
                variant="outline"
                className="border-gray-300 dark:border-slate-600"
              >
                Sign Out
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Posts */}
          <div className="lg:col-span-2">
            <div className="mb-6">
              <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
                Your Posts ({userPosts?.length || 0})
              </h2>
            </div>

            {postsLoading ? (
              <div className="space-y-6">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="bg-white dark:bg-slate-800 rounded-lg shadow-sm border border-gray-200 dark:border-slate-700 p-6">
                    <div className="flex space-x-4">
                      <div className="space-y-2">
                        <Skeleton className="h-6 w-6" />
                        <Skeleton className="h-4 w-8" />
                        <Skeleton className="h-6 w-6" />
                      </div>
                      <div className="flex-1 space-y-3">
                        <Skeleton className="h-4 w-3/4" />
                        <Skeleton className="h-6 w-full" />
                        <Skeleton className="h-20 w-full" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : userPosts && userPosts.length > 0 ? (
              <div className="space-y-6">
                {userPosts.map((post) => (
                  <PostCard key={post.id} post={post} onUpdate={() => {}} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700">
                <MessageSquare className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <div className="text-gray-500 dark:text-gray-400 mb-4">
                  You haven't posted anything yet. Share your first experience!
                </div>
                <div className="space-x-4">
                  <Button className="bg-reddit-orange hover:bg-reddit-orange/90 text-white">
                    Write Review
                  </Button>
                  <Button className="bg-professional-blue hover:bg-professional-blue/90 text-white">
                    Create Discussion
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Karma Breakdown */}
            <Card className="bg-white dark:bg-slate-800 border-gray-200 dark:border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5" />
                  <span>Karma Breakdown</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className={`text-4xl font-bold ${getKarmaColor(user.karma)} mb-2`}>
                    {user.karma}
                  </div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Total Karma</div>
                </div>
                
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-300">Reviews written</span>
                    <span className="font-medium">+{reviewPosts.length * 5}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-300">Discussions started</span>
                    <span className="font-medium">{discussionPosts.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-300">Upvotes received</span>
                    <span className="font-medium text-positive">
                      +{userPosts?.reduce((sum, post) => sum + post.upvotes, 0) || 0}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-300">Downvotes received</span>
                    <span className="font-medium text-negative">
                      -{userPosts?.reduce((sum, post) => sum + post.downvotes, 0) || 0}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Joined Bowls */}
            <Card className="bg-white dark:bg-slate-800 border-gray-200 dark:border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Award className="h-5 w-5" />
                  <span>Joined Bowls</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {bowlsLoading ? (
                  <div className="space-y-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center space-x-3">
                        <Skeleton className="h-8 w-8 rounded-full" />
                        <div>
                          <Skeleton className="h-4 w-24 mb-1" />
                          <Skeleton className="h-3 w-16" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : userBowls && userBowls.length > 0 ? (
                  <div className="space-y-3">
                    {userBowls.map((membership) => (
                      <div key={membership.id} className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-professional-blue rounded-full flex items-center justify-center">
                          <Award className="h-4 w-4 text-white" />
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-900 dark:text-white">
                            {membership.bowl.name}
                          </div>
                          <div className="text-xs text-gray-500">
                            {membership.bowl.memberCount} members
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center text-gray-500 dark:text-gray-400 py-4">
                    No bowls joined yet
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Activity Stats */}
            <Card className="bg-white dark:bg-slate-800 border-gray-200 dark:border-slate-700">
              <CardHeader>
                <CardTitle>Activity Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-reddit-orange">{reviewPosts.length}</div>
                    <div className="text-xs text-gray-500">Reviews</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-professional-blue">{discussionPosts.length}</div>
                    <div className="text-xs text-gray-500">Discussions</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-positive">
                      {userPosts?.reduce((sum, post) => sum + post.upvotes, 0) || 0}
                    </div>
                    <div className="text-xs text-gray-500">Upvotes</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-neutral">{userBowls?.length || 0}</div>
                    <div className="text-xs text-gray-500">Bowls</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
