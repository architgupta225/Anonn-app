import React, { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { 
  ChevronDown, 
  X, 
  Plus, 
  FileImage, 
  AtSign, 
  CheckSquare,
  Building,
  MessageCircle
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";

interface Bowl {
  id: number;
  name: string;
  description: string;
  category: string;
  icon?: string;
}

interface Organization {
  id: number;
  name: string;
  description: string;
}

interface PollOption {
  id: string;
  text: string;
}

export default function CreatePost() {
  const [location] = useLocation();
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [selectedBowl, setSelectedBowl] = useState<Bowl | null>(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [showBowlSelector, setShowBowlSelector] = useState(false);
  const [showPollSection, setShowPollSection] = useState(false);
  const [bowlSearch, setBowlSearch] = useState("");
  const [pollOptions, setPollOptions] = useState<PollOption[]>([
    { id: "1", text: "Option #1" },
    { id: "2", text: "Option #2" }
  ]);
  const [allowMultipleSelections, setAllowMultipleSelections] = useState(false);
  const [companySearch, setCompanySearch] = useState("");
  const [selectedCompany, setSelectedCompany] = useState<Organization | null>(null);
  const [isDraft, setIsDraft] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch bowls and organizations
  const { data: bowls } = useQuery<Bowl[]>({
    queryKey: ["bowls"],
    queryFn: async () => {
      const response = await fetch("/api/bowls", {
        credentials: "include",
      });
      return response.json();
    }
  });

  const { data: organizations } = useQuery<Organization[]>({
    queryKey: ["organizations"],
    queryFn: async () => {
      const response = await fetch("/api/organizations", {
        credentials: "include",
      });
      return response.json();
    }
  });

  // Handle URL parameters
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const bowlId = urlParams.get('bowlId');
    const type = urlParams.get('type');
    
    if (bowlId && bowls) {
      const bowl = bowls.find(b => b.id === parseInt(bowlId));
      if (bowl) {
        setSelectedBowl(bowl);
      }
    }
    
    // Auto-enable poll mode if type=poll
    if (type === 'poll') {
      setShowPollSection(true);
    }
  }, [bowls]);

  const filteredOrganizations = organizations?.filter(org =>
    org.name.toLowerCase().includes(companySearch.toLowerCase())
  ) || [];

  const filteredBowls = bowls?.filter(bowl =>
    bowl.name.toLowerCase().includes(bowlSearch.toLowerCase()) ||
    bowl.description.toLowerCase().includes(bowlSearch.toLowerCase())
  ) || [];

  const addPollOption = () => {
    const newId = (pollOptions.length + 1).toString();
    setPollOptions([...pollOptions, { id: newId, text: `Option #${newId}` }]);
  };

  const removePollOption = (id: string) => {
    if (pollOptions.length > 2) {
      setPollOptions(pollOptions.filter(option => option.id !== id));
    }
  };

  const updatePollOption = (id: string, text: string) => {
    setPollOptions(pollOptions.map(option => 
      option.id === id ? { ...option, text } : option
    ));
  };

  const saveDraft = () => {
    const draft = {
      title,
      content,
      selectedBowl,
      selectedCompany,
      showPollSection,
      pollOptions,
      allowMultipleSelections,
      timestamp: new Date().toISOString()
    };
    localStorage.setItem('postDraft', JSON.stringify(draft));
    setIsDraft(true);
    setTimeout(() => setIsDraft(false), 2000);
  };

  const loadDraft = () => {
    const savedDraft = localStorage.getItem('postDraft');
    if (savedDraft) {
      const draft = JSON.parse(savedDraft);
      setTitle(draft.title || '');
      setContent(draft.content || '');
      setSelectedBowl(draft.selectedBowl || null);
      setSelectedCompany(draft.selectedCompany || null);
      setShowPollSection(draft.showPollSection || false);
      setPollOptions(draft.pollOptions || [{ id: "1", text: "Option #1" }, { id: "2", text: "Option #2" }]);
      setAllowMultipleSelections(draft.allowMultipleSelections || false);
    }
  };

  const clearDraft = () => {
    localStorage.removeItem('postDraft');
  };

  const handlePost = async () => {
    if (!selectedBowl || !title.trim() || !content.trim()) {
      alert("Please fill in all required fields");
      return;
    }

    setIsSubmitting(true);

    try {
      const postData = {
        title: title.trim(),
        content: content.trim(),
        bowlId: selectedBowl.id,
        organizationId: selectedCompany?.id,
        type: showPollSection ? "poll" : "discussion",
        poll: showPollSection ? {
          title: title.trim(),
          description: content.trim(),
          options: pollOptions.map(opt => opt.text),
          allowMultipleSelections
        } : null
      };

      const response = await fetch("/api/posts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify(postData),
      });

      if (response.ok) {
        clearDraft(); // Clear draft after successful post
        setLocation("/");
      } else {
        alert("Failed to create post");
      }
    } catch (error) {
      console.error("Error creating post:", error);
      alert("Failed to create post");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-100 via-red-50 to-pink-100 dark:from-slate-900 dark:via-slate-800 dark:to-purple-900/20">
      {/* Animated background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-gradient-to-br from-orange-400/30 to-red-500/30 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-gradient-to-br from-blue-400/30 to-purple-500/30 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-br from-yellow-400/20 to-orange-500/20 rounded-full blur-2xl animate-pulse delay-500"></div>
      </div>

      <div className="relative max-w-4xl mx-auto px-6 py-8">
        <Card className="shadow-2xl border-0 bg-white/95 dark:bg-slate-800/95 backdrop-blur-xl rounded-2xl overflow-hidden">
          {/* Header with gradient */}
          <div className="bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 p-6 text-white relative overflow-hidden">
            {/* Header background pattern */}
            <div className="absolute inset-0 bg-gradient-to-r from-orange-600/20 via-red-600/20 to-pink-600/20"></div>
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl"></div>
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full blur-xl"></div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                  <MessageCircle className="w-6 h-6" />
                </div>
                <div>
                  <CardTitle className="text-2xl font-bold">Create Your Post</CardTitle>
                  <p className="text-orange-100 text-sm">Share your thoughts with the community</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Button 
                  variant="outline" 
                  onClick={() => setLocation("/")}
                  className="border-2 border-white/40 text-white hover:bg-white/20 backdrop-blur-sm font-semibold px-6 py-2"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handlePost}
                  disabled={isSubmitting}
                  className="bg-white text-orange-600 hover:bg-orange-50 shadow-xl hover:shadow-2xl transition-all duration-300 font-bold px-8 py-2 border-2 border-white/20"
                >
                  {isSubmitting ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-5 h-5 border-2 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
                      <span>Posting...</span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <span>Post</span>
                      <div className="w-3 h-3 bg-orange-600 rounded-full animate-pulse"></div>
                    </div>
                  )}
                </Button>
              </div>
            </div>
          </div>
          
          <CardContent className="space-y-8 p-8">
            {/* Bowl Selection */}
            <div className="relative">
              <div 
                className="flex items-center justify-between p-4 border border-gray-300 rounded-lg cursor-pointer hover:border-gray-400 transition-colors bg-white"
                onClick={() => setShowBowlSelector(!showBowlSelector)}
              >
                <div className="flex items-center space-x-3">
                  {selectedBowl ? (
                    <>
                      <div className="w-10 h-10 bg-gradient-to-br from-reddit-orange to-orange-600 rounded-full flex items-center justify-center shadow-sm">
                        <MessageCircle className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <span className="font-semibold text-gray-900">{selectedBowl.name}</span>
                        <div className="text-sm text-gray-500">{selectedBowl.description}</div>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                        <MessageCircle className="w-5 h-5 text-gray-500" />
                      </div>
                      <span className="text-gray-500 font-medium">Select Channel</span>
                    </>
                  )}
                </div>
                <ChevronDown className={`w-5 h-5 text-gray-500 transition-transform ${showBowlSelector ? 'rotate-180' : ''}`} />
              </div>

              {showBowlSelector && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-300 rounded-lg shadow-xl z-10 max-h-80 overflow-hidden">
                  {/* Search Input */}
                  <div className="p-3 border-b border-gray-200">
                    <Input
                      placeholder="Search channels..."
                      value={bowlSearch}
                      onChange={(e) => setBowlSearch(e.target.value)}
                      className="border-gray-200 focus:border-reddit-orange focus:ring-reddit-orange"
                    />
                  </div>
                  
                  {/* Bowl List */}
                  <div className="max-h-60 overflow-y-auto">
                    {filteredBowls.length > 0 ? (
                      filteredBowls.map((bowl) => (
                        <div
                          key={bowl.id}
                          className="flex items-center space-x-3 p-4 hover:bg-gray-50 cursor-pointer transition-colors"
                          onClick={() => {
                            setSelectedBowl(bowl);
                            setShowBowlSelector(false);
                            setBowlSearch("");
                          }}
                        >
                          <div className="w-10 h-10 bg-gradient-to-br from-reddit-orange to-orange-600 rounded-full flex items-center justify-center shadow-sm">
                            <MessageCircle className="w-5 h-5 text-white" />
                          </div>
                          <div className="flex-1">
                            <div className="font-semibold text-gray-900">{bowl.name}</div>
                            <div className="text-sm text-gray-500">{bowl.description}</div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="p-4 text-center text-gray-500">
                        No channels found
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Title Input */}
            <div className="relative group">
              <label className="block text-sm font-bold text-gray-800 dark:text-gray-200 mb-3 flex items-center space-x-2">
                <span className="w-3 h-3 bg-gradient-to-r from-orange-500 to-red-500 rounded-full animate-pulse"></span>
                <span>Title</span>
              </label>
              <div className="relative">
                <Input
                  placeholder="Write a compelling title..."
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="border-2 border-orange-200 focus:border-orange-500 focus:ring-orange-500/20 text-lg font-semibold rounded-xl transition-all duration-300 group-hover:border-orange-300 bg-gradient-to-r from-orange-50/50 to-red-50/50"
                />
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                  <div className="w-3 h-3 bg-gradient-to-r from-orange-500 to-red-500 rounded-full animate-pulse"></div>
                </div>
              </div>
            </div>

            {/* Draft and Content Type Options */}
            <div className="flex items-center justify-between p-4 bg-gradient-to-r from-orange-50 to-red-50 rounded-xl border border-orange-200">
              <div className="flex items-center space-x-3">
                <Button
                  variant={showPollSection ? "default" : "outline"}
                  size="sm"
                  onClick={() => setShowPollSection(!showPollSection)}
                  className={`${
                    showPollSection 
                      ? "bg-gradient-to-r from-orange-500 to-red-500 text-white shadow-lg border-0" 
                      : "border-2 border-orange-300 hover:border-orange-500 hover:bg-orange-50"
                  } transition-all duration-300 font-semibold`}
                >
                  <CheckSquare className="w-4 h-4 mr-2" />
                  Poll
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={saveDraft}
                  className="border-2 border-green-400 text-green-700 hover:bg-green-100 hover:border-green-500 transition-all duration-300 font-semibold"
                >
                  💾 Save Draft
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={loadDraft}
                  className="border-2 border-blue-400 text-blue-700 hover:bg-blue-100 hover:border-blue-500 transition-all duration-300 font-semibold"
                >
                  📄 Load Draft
                </Button>
              </div>
              
              {isDraft && (
                <div className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-green-100 to-emerald-100 text-green-800 rounded-full text-sm font-semibold animate-pulse border border-green-300">
                  <span className="text-green-600">✓</span>
                  <span>Draft saved!</span>
                </div>
              )}
            </div>

            {/* Poll Section */}
            {showPollSection && (
              <Card className="border border-gray-200">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <CheckSquare className="w-4 h-4 text-reddit-orange" />
                      <span className="font-medium">Polls</span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowPollSection(false)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                  <p className="text-sm text-gray-500">* Polls cannot be edited once posted.</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  {pollOptions.map((option) => (
                    <div key={option.id} className="flex items-center space-x-2">
                      <Input
                        value={option.text}
                        onChange={(e) => updatePollOption(option.id, e.target.value)}
                        className="flex-1"
                      />
                      {pollOptions.length > 2 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removePollOption(option.id)}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={addPollOption}
                    className="w-full"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    ADD OPTION
                  </Button>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="multiple-selections"
                      checked={allowMultipleSelections}
                      onCheckedChange={(checked) => setAllowMultipleSelections(checked as boolean)}
                    />
                    <label htmlFor="multiple-selections" className="text-sm">
                      Allow multiple selections
                    </label>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Content Area */}
            <div className="relative group">
              <label className="block text-sm font-bold text-gray-800 dark:text-gray-200 mb-3 flex items-center space-x-2">
                <span className="w-3 h-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full animate-pulse"></span>
                <span>Content</span>
              </label>
              <div className="relative">
                <Textarea
                  placeholder="Share your thoughts, ask questions, or start a discussion..."
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="min-h-[200px] border-2 border-blue-200 focus:border-blue-500 focus:ring-blue-500/20 resize-none text-base leading-relaxed rounded-xl transition-all duration-300 group-hover:border-blue-300 bg-gradient-to-r from-blue-50/50 to-purple-50/50"
                />
                <div className="absolute bottom-3 right-3">
                  <div className="flex items-center space-x-1 text-xs font-semibold text-blue-600 bg-white/80 px-2 py-1 rounded-full">
                    <span>{content.length}</span>
                    <span>/</span>
                    <span>∞</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between mt-3 p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-200">
                <p className="text-sm text-blue-700 flex items-center space-x-2 font-medium">
                  <span>💡</span>
                  <span>Keep it classy. No personal information or trade secrets.</span>
                </p>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full animate-pulse"></div>
                </div>
              </div>
            </div>

            {/* Company Search */}
            <div className="relative group">
              <label className="block text-sm font-bold text-gray-800 dark:text-gray-200 mb-3 flex items-center space-x-2">
                <span className="w-3 h-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full animate-pulse"></span>
                <span>Company (Optional)</span>
              </label>
              <div className="relative">
                <Input
                  placeholder="Search for the company name..."
                  value={companySearch}
                  onChange={(e) => setCompanySearch(e.target.value)}
                  className="border-2 border-purple-200 focus:border-purple-500 focus:ring-purple-500/20 rounded-xl transition-all duration-300 group-hover:border-purple-300 bg-gradient-to-r from-purple-50/50 to-pink-50/50"
                />
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                  <Building className="w-5 h-5 text-purple-500" />
                </div>
              </div>
              {companySearch && filteredOrganizations.length > 0 && (
                <div className="mt-3 border-2 border-purple-200 rounded-xl max-h-40 overflow-y-auto bg-white shadow-xl">
                  {filteredOrganizations.map((org) => (
                    <div
                      key={org.id}
                      className="flex items-center space-x-3 p-4 hover:bg-gradient-to-r hover:from-purple-50 hover:to-pink-50 cursor-pointer transition-all duration-300 border-b border-purple-100 last:border-b-0"
                      onClick={() => {
                        setSelectedCompany(org);
                        setCompanySearch(org.name);
                      }}
                    >
                      <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center shadow-lg">
                        <Building className="w-4 h-4 text-white" />
                      </div>
                      <span className="font-bold text-gray-900">{org.name}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>


          </CardContent>
        </Card>
      </div>
    </div>
  );
} 