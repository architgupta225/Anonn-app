import { useEffect, useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import Navigation from "@/components/Navigation";
import Sidebar from "@/components/Sidebar";
import PostCard from "@/components/PostCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Users, MessageSquare, Plus, UserPlus, UserMinus, 
  TrendingUp, Calendar, Eye, Share2, Settings, 
  MoreHorizontal, Star, Flame, Globe, Building2,
  Clock, BarChart3, Users2, Hash, Bookmark
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth.tsx";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Bowl, PostWithDetails, BowlFollow, User } from "@shared/schema";

export default function BowlPage() {
  const params = useParams();
  const bowlId = parseInt(params.id as string);
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<'discussions' | 'polls' | 'reviews'>('discussions');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const handleCreatePost = () => {
    setLocation(`/create-post?bowlId=${bowlId}`);
  };

  const { data: bowl, isLoading: bowlLoading, error: bowlError } = useQuery<Bowl>({
    queryKey: ["/api/bowls", bowlId],
    enabled: !!bowlId,
    retry: false,
  });

  const { data: posts, isLoading: postsLoading, error: postsError, refetch } = useQuery<PostWithDetails[]>({
    queryKey: ["/api/posts", "bowl", bowlId],
    queryFn: async () => {
      const response = await fetch(`/api/posts?bowlId=${bowlId}&type=discussion`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error(`${response.status}: ${response.statusText}`);
      }
      
      return response.json();
    },
    enabled: !!bowlId,
    retry: false,
  });

  const { data: userBowls } = useQuery<(BowlFollow & { bowl: Bowl })[]>({
    queryKey: ["/api/user/bowls"],
    enabled: isAuthenticated,
    retry: false,
  });

  const { data: isFollowing } = useQuery<{ isFollowing: boolean }>({
    queryKey: ["/api/bowls", bowlId, "following"],
    enabled: isAuthenticated && !!bowlId,
    retry: false,
  });

  const followBowlMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/bowls/${bowlId}/follow`, {});
    },
    onSuccess: () => {
      toast({
        title: "Followed!",
        description: "You're now following this channel.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user/bowls"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bowls", bowlId, "following"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bowls"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to follow channel. Please try again.",
        variant: "destructive",
      });
    },
  });

  const unfollowBowlMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/bowls/${bowlId}/follow`, {});
    },
    onSuccess: () => {
      toast({
        title: "Unfollowed",
        description: "You're no longer following this channel.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user/bowls"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bowls", bowlId, "following"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bowls"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to unfollow channel. Please try again.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (bowl) {
      document.title = `${bowl.name} - Apocalypse`;
    }
  }, [bowl]);

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  useEffect(() => {
    if ((bowlError && isUnauthorizedError(bowlError as Error)) || 
        (postsError && isUnauthorizedError(postsError as Error))) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [bowlError, postsError, toast]);

  if (authLoading || bowlLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white dark:from-slate-900 dark:to-slate-800">
        <Navigation />
        <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
          <Skeleton className="h-64 w-full mb-8" />
          <div className="space-y-6">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-64 w-full" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!bowl) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white dark:from-slate-900 dark:to-slate-800">
        <Navigation />
        <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center py-12">
            <div className="w-20 h-20 bg-gradient-to-br from-orange-400 to-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <Users className="h-10 w-10 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Channel not found
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-md mx-auto">
              The channel you're looking for doesn't exist or has been removed.
            </p>
          </div>
        </div>
      </div>
    );
  }

  const isUserFollowing = isFollowing?.isFollowing || false;
  const getBowlIcon = (name: string) => name?.charAt(0).toUpperCase() || '?';

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white dark:from-slate-900 dark:to-slate-800">
      <Navigation />
      {/* Main Layout */}
      <div className="flex w-full h-screen">
        {/* Left Sidebar - Fixed position like Blind */}
        <aside className={`${sidebarOpen ? 'w-[240px]' : 'w-[60px]'} h-[calc(100vh-4rem)] sticky top-16 bg-white dark:bg-slate-800 border-r border-gray-200 dark:border-slate-700 overflow-y-auto transition-all duration-300 flex-shrink-0`}>
          <Sidebar 
            onCreatePost={handleCreatePost} 
            onCreateReview={() => {}} 
            onToggleSidebar={toggleSidebar} 
            isOpen={sidebarOpen} 
          />
        </aside>

        {/* Sidebar Toggle Button */}
        <button
          onClick={toggleSidebar}
          className="lg:hidden fixed top-20 left-4 z-40 p-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-md shadow-md hover:bg-gray-50 dark:hover:bg-slate-700"
        >
          <svg className="w-5 h-5 text-gray-600 dark:text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>

        {/* Main Content Area */}
        <main className="flex-1 min-w-0 bg-gradient-to-br from-gray-50 to-white dark:from-slate-900 dark:to-slate-800 overflow-y-auto">
          <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Banner */}
        <div className="relative mb-8">
          {/* Cover Banner */}
          <div className="h-64 bg-gradient-to-br from-orange-400 via-red-500 to-pink-500 rounded-2xl relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-black/20 to-transparent"></div>
                         <div className="absolute inset-0 bg-gradient-to-r from-black/20 to-transparent opacity-30"></div>
          </div>
          
          {/* Channel Info Card */}
          <div className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-600 rounded-2xl -mt-20 mx-4 relative z-10 p-8 shadow-xl">
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-6">
                <div className="w-24 h-24 bg-gradient-to-br from-orange-400 to-red-500 rounded-2xl border-4 border-white dark:border-slate-800 flex items-center justify-center shadow-lg">
                  <span className="text-white text-3xl font-bold">{getBowlIcon(bowl.name)}</span>
                </div>
                
                <div className="pt-2">
                  <div className="flex items-center space-x-3 mb-3">
                    <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                      {bowl.name}
                    </h1>
                    <Badge variant="outline" className="bg-green-50 dark:bg-green-900/30 text-green-700 dark:text-green-300 border-green-200 dark:border-green-700">
                      <Globe className="h-3 w-3 mr-1" />
                      Public
                    </Badge>
                  </div>
                  
                  <div className="flex items-center space-x-6 text-sm text-gray-500 dark:text-gray-400 mb-4">
                    <div className="flex items-center space-x-2">
                      <Users className="h-4 w-4" />
                      <span>{bowl.memberCount.toLocaleString()} members</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <MessageSquare className="h-4 w-4" />
                      <span>{posts?.length || 0} posts</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4" />
                      <span>Created {bowl.createdAt ? new Date(bowl.createdAt).toLocaleDateString() : 'Recently'}</span>
                    </div>
                  </div>
                  
                  {bowl.description && (
                    <p className="text-gray-600 dark:text-gray-300 text-lg leading-relaxed max-w-3xl">
                      {bowl.description}
                    </p>
                  )}
                </div>
              </div>
              
              <div className="flex space-x-3 pt-2">
                {isAuthenticated && (
                  <>
                    <Button 
                      onClick={() => isUserFollowing ? unfollowBowlMutation.mutate() : followBowlMutation.mutate()}
                      disabled={followBowlMutation.isPending || unfollowBowlMutation.isPending}
                      className={`px-6 py-3 rounded-xl font-medium transition-all duration-200 ${
                        isUserFollowing 
                          ? "bg-gray-100 hover:bg-gray-200 text-gray-700 dark:bg-slate-700 dark:hover:bg-slate-600 dark:text-gray-300" 
                          : "bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg hover:shadow-xl"
                      }`}
                    >
                      {isUserFollowing ? (
                        <>
                          <UserMinus className="h-4 w-4 mr-2" />
                          Unfollow
                        </>
                      ) : (
                        <>
                          <UserPlus className="h-4 w-4 mr-2" />
                          Follow
                        </>
                      )}
                    </Button>
                    <Button variant="outline" className="px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-slate-600 hover:border-orange-500 dark:hover:border-orange-400">
                      <Share2 className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" className="px-4 py-3 rounded-xl border-2 border-gray-200 dark:border-slate-600 hover:border-orange-500 dark:hover:border-orange-400">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-slate-800 dark:to-slate-700 border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-600 dark:text-blue-400">Total Members</p>
                  <p className="text-2xl font-bold text-blue-900 dark:text-blue-100">{bowl.memberCount.toLocaleString()}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-xl flex items-center justify-center">
                  <Users className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-slate-800 dark:to-slate-700 border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-green-600 dark:text-green-400">Active Posts</p>
                  <p className="text-2xl font-bold text-green-900 dark:text-green-100">{posts?.length || 0}</p>
                </div>
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-xl flex items-center justify-center">
                  <MessageSquare className="h-6 w-6 text-green-600 dark:text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-violet-50 dark:from-slate-800 dark:to-slate-700 border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-600 dark:text-purple-400">Growth Rate</p>
                  <p className="text-2xl font-bold text-purple-900 dark:text-purple-100">+12%</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-xl flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-50 to-red-50 dark:from-slate-800 dark:to-slate-700 border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-orange-600 dark:text-orange-400">Engagement</p>
                  <p className="text-2xl font-bold text-orange-900 dark:text-orange-100">89%</p>
                </div>
                <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900/30 rounded-xl flex items-center justify-center">
                  <BarChart3 className="h-6 w-6 text-orange-600 dark:text-orange-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Content Tabs */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex space-x-1 bg-gray-100 dark:bg-slate-700 rounded-xl p-1">
            <Button
              variant={activeTab === 'discussions' ? 'default' : 'ghost'}
              onClick={() => setActiveTab('discussions')}
              className={`rounded-lg ${
                activeTab === 'discussions' 
                  ? 'bg-white dark:bg-slate-600 text-gray-900 dark:text-white shadow-sm' 
                  : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
              }`}
            >
              <MessageSquare className="h-4 w-4 mr-2" />
              Discussions
            </Button>
            <Button
              variant={activeTab === 'polls' ? 'default' : 'ghost'}
              onClick={() => setActiveTab('polls')}
              className={`rounded-lg ${
                activeTab === 'polls' 
                  ? 'bg-white dark:bg-slate-600 text-gray-900 dark:text-white shadow-sm' 
                  : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
              }`}
            >
              <BarChart3 className="h-4 w-4 mr-2" />
              Polls
            </Button>
            <Button
              variant={activeTab === 'reviews' ? 'default' : 'ghost'}
              onClick={() => setActiveTab('reviews')}
              className={`rounded-lg ${
                activeTab === 'reviews' 
                  ? 'bg-white dark:bg-slate-600 text-gray-900 dark:text-white shadow-sm' 
                  : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
              }`}
            >
              <Star className="h-4 w-4 mr-2" />
              Reviews
            </Button>
          </div>

          {isAuthenticated && (
            <Button 
              onClick={handleCreatePost}
              className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-6 py-3 rounded-xl font-medium shadow-lg hover:shadow-xl"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Post
            </Button>
          )}
        </div>

        {/* Posts Content */}
        {activeTab === 'discussions' && (
          <>
            {postsLoading ? (
              <div className="space-y-6">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="bg-white dark:bg-slate-800 rounded-2xl shadow-lg border border-gray-100 dark:border-slate-700 p-6">
                    <div className="flex space-x-4">
                      <div className="space-y-2">
                        <Skeleton className="h-6 w-6" />
                        <Skeleton className="h-4 w-8" />
                        <Skeleton className="h-6 w-6" />
                      </div>
                      <div className="flex-1 space-y-3">
                        <Skeleton className="h-4 w-3/4" />
                        <Skeleton className="h-6 w-full" />
                        <Skeleton className="h-20 w-full" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : posts && posts.length > 0 ? (
              <div className="space-y-6">
                {posts.map((post) => (
                  <PostCard key={post.id} post={post} onUpdate={refetch} />
                ))}
              </div>
            ) : (
              <div className="text-center py-16 bg-white dark:bg-slate-800 rounded-2xl border border-gray-100 dark:border-slate-700 shadow-lg">
                <div className="w-20 h-20 bg-gradient-to-br from-orange-400 to-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                  <MessageSquare className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                  No discussions yet
                </h3>
                <p className="text-gray-600 dark:text-gray-300 text-lg mb-8 max-w-md mx-auto">
                  Be the first to start a discussion in this channel! Share your thoughts and get the conversation going.
                </p>
                {isAuthenticated && (
                  <Button 
                    onClick={handleCreatePost}
                    className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-8 py-4 rounded-xl font-medium text-lg shadow-lg hover:shadow-xl"
                  >
                    <Plus className="h-5 w-5 mr-2" />
                    Start First Discussion
                  </Button>
                )}
              </div>
            )}

            {/* Load More */}
            {posts && posts.length > 0 && (
              <div className="text-center mt-12">
                <Button 
                  variant="outline" 
                  className="bg-white dark:bg-slate-800 text-gray-700 dark:text-gray-300 border-2 border-gray-200 dark:border-slate-600 hover:border-orange-500 dark:hover:border-orange-400 px-8 py-3 rounded-xl font-medium"
                >
                  Load More Posts
                </Button>
              </div>
            )}
          </>
        )}

        {/* Polls Tab */}
        {activeTab === 'polls' && (
          <div className="text-center py-16 bg-white dark:bg-slate-800 rounded-2xl border border-gray-100 dark:border-slate-700 shadow-lg">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <BarChart3 className="h-10 w-10 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              No polls yet
            </h3>
            <p className="text-gray-600 dark:text-gray-300 text-lg">
              Polls will appear here when they're created in this channel.
            </p>
          </div>
        )}

        {/* Reviews Tab */}
        {activeTab === 'reviews' && (
          <div className="text-center py-16 bg-white dark:bg-slate-800 rounded-2xl border border-gray-100 dark:border-slate-700 shadow-lg">
            <div className="w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <Star className="h-10 w-10 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              No reviews yet
            </h3>
            <p className="text-gray-600 dark:text-gray-300 text-lg">
              Reviews will appear here when they're posted in this channel.
            </p>
          </div>
        )}
          </div>
        </main>
      </div>
    </div>
  );
}
