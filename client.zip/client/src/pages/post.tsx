import React, { useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  MessageSquare, 
  Share2, 
  Bookmark, 
  Clock,
  Building,
  Users,
  User,
  ArrowLeft,
  BarChart3,
  ChevronRight,
  Eye,
  Heart
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useAuth } from "@/hooks/useAuth";
import Navigation from "@/components/Navigation";
import Sidebar from "@/components/Sidebar";
import VoteButtons from "@/components/VoteButtons";
import CommentForm from "@/components/CommentForm";
import CommentReply from "@/components/CommentReply";
import type { PostWithDetails, CommentWithDetails } from "@shared/schema";

export default function PostPage() {
  const [location, setLocation] = useLocation();
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const [showComments, setShowComments] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // Get post ID from URL
  const postId = new URLSearchParams(window.location.search).get('id');
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const handleCreatePost = () => {
    window.location.href = '/create-post';
  };

  // Fetch post data
  const { data: post, isLoading: postLoading, refetch } = useQuery<PostWithDetails>({
    queryKey: ["post", postId],
    queryFn: async () => {
      if (!postId) throw new Error("No post ID provided");
      const response = await fetch(`/api/posts/${postId}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error(`${response.status}: ${response.statusText}`);
      }
      
      return response.json();
    },
    enabled: !!postId && isAuthenticated,
  });

  // Fetch comments
  const { data: comments, isLoading: commentsLoading, refetch: refetchComments } = useQuery<CommentWithDetails[]>({
    queryKey: ["/api/posts", postId, "comments"],
    queryFn: async () => {
      if (!postId) throw new Error("No post ID provided");
      const response = await fetch(`/api/posts/${postId}/comments`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error(`${response.status}: ${response.statusText}`);
      }
      
      return response.json();
    },
    enabled: !!postId && isAuthenticated,
  });

  const queryClient = useQueryClient();



  const getPostTypeLabel = () => {
    if (!post) return '';
    if (post.type === 'review') return 'Discussion';
    if (post.type === 'poll') return 'Poll';
    return 'Discussion';
  };

  const getAuthorDisplay = () => {
    if (!post) return '';
    if (post.isAnonymous) {
      return "anonymous";
    }
    
    const author = post.author;
    if (author.firstName && author.lastName) {
      return `${author.firstName} ${author.lastName}`;
    }
    
    return author.email?.split('@')[0] || 'User';
  };



  const handlePollClick = () => {
    if (post?.type === 'poll') {
      // Navigate to polls page for now
      // In the future, we could add a pollId field to posts to link to specific polls
      window.location.href = '/polls';
    }
  };

  const truncateContent = (content: string, maxLength: number = 300) => {
    if (content.length <= maxLength) return content;
    return content.substring(0, maxLength).trim() + '...';
  };



  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
        <Navigation />
        <div className="flex w-full h-screen">
          <aside className={`${sidebarOpen ? 'w-[240px]' : 'w-[60px]'} h-[calc(100vh-4rem)] sticky top-16 bg-white dark:bg-slate-800 border-r border-gray-200 dark:border-slate-700 overflow-y-auto transition-all duration-300 flex-shrink-0`}>
            <div className="p-4 space-y-4">
              {[1,2,3,4].map(i => <Skeleton key={i} className="h-8 w-full" />)}
            </div>
          </aside>
          <main className="flex-1 min-w-0 bg-gray-50 dark:bg-slate-900 overflow-y-auto">
            <div className="px-4 sm:px-6 lg:px-8 py-6 w-full">
              {[1,2,3].map(i => <Skeleton key={i} className="h-48 w-full mb-4" />)}
            </div>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      <Navigation />
      <div className="flex w-full h-screen">
        {/* Left Sidebar */}
        <aside className={`${sidebarOpen ? 'w-[240px]' : 'w-[60px]'} h-[calc(100vh-4rem)] sticky top-16 bg-white dark:bg-slate-800 border-r border-gray-200 dark:border-slate-700 overflow-y-auto transition-all duration-300 flex-shrink-0`}>
          <Sidebar 
            onCreatePost={handleCreatePost} 
            onCreateReview={handleCreatePost}
            onToggleSidebar={toggleSidebar}
            isOpen={sidebarOpen}
          />
        </aside>

        {/* Sidebar Toggle Button */}
        <button
          onClick={toggleSidebar}
          className="fixed top-20 left-4 z-50 lg:hidden bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-md p-2 shadow-md"
        >
          <MessageSquare className="h-4 w-4" />
        </button>

        {/* Main Content */}
        <main className="flex-1 min-w-0 bg-gray-50 dark:bg-slate-900 overflow-y-auto">
          <div className="px-4 sm:px-6 lg:px-8 py-6 w-full">
            {/* Back Button */}
            <div className="mb-6">
              <Button 
                variant="ghost" 
                onClick={() => setLocation("/")}
                className="flex items-center space-x-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Back to Feed</span>
              </Button>
            </div>

            {postLoading ? (
              <Card className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 shadow-sm">
                <CardContent className="p-6">
                  <div className="animate-pulse space-y-4">
                    <div className="flex items-center space-x-3">
                      <Skeleton className="h-8 w-8 rounded-full" />
                      <div className="space-y-2">
                        <Skeleton className="h-4 w-32" />
                        <Skeleton className="h-3 w-24" />
                      </div>
                    </div>
                    <Skeleton className="h-6 w-full mb-3" />
                    <Skeleton className="h-20 w-full mb-4" />
                    <div className="flex items-center space-x-4">
                      <Skeleton className="h-8 w-16" />
                      <Skeleton className="h-8 w-16" />
                      <Skeleton className="h-8 w-16" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : post ? (
              <Card className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    {/* Vote Buttons */}
                    <div className="transform hover:scale-105 transition-transform duration-300">
                      <VoteButtons 
                        targetId={post.id}
                        targetType="post"
                        upvotes={post.upvotes}
                        downvotes={post.downvotes}
                        userVote={post.userVote}
                        onUpdate={refetch}
                      />
                    </div>

                    {/* Post Content */}
                    <div className="flex-1">
                      {/* Post Meta */}
                      <div className="flex items-center space-x-2 mb-3 flex-wrap">
                        {post.type === 'poll' && (
                          <Badge className="bg-gradient-to-r from-blue-500 to-purple-600 text-white text-xs px-3 py-1 font-medium">
                            <BarChart3 className="w-3 h-3 mr-1" />
                            Poll
                          </Badge>
                        )}
                        
                        <span className="text-sm text-muted-foreground">
                          {getPostTypeLabel()} • Posted by
                        </span>
                        
                        <div className="flex items-center space-x-1">
                          {!post.isAnonymous && post.author.profileImageUrl ? (
                            <Avatar className="h-5 w-5">
                              <AvatarImage src={post.author.profileImageUrl} />
                              <AvatarFallback>
                                <User className="h-2 w-2" />
                              </AvatarFallback>
                            </Avatar>
                          ) : null}
                          
                          <button
                            onClick={() => window.open(`/profile?id=${post.author.id}`, '_blank')}
                            className="text-sm font-medium text-reddit-orange hover:text-reddit-orange/80 hover:underline cursor-pointer"
                          >
                            {getAuthorDisplay()}
                          </button>
                        </div>
                        
                        <span className="text-sm text-muted-foreground flex items-center">
                          <Clock className="h-3 w-3 mr-1" />
                          {formatDistanceToNow(new Date(post.createdAt || ''), { addSuffix: true })}
                        </span>
                        
                        {post.organization && (
                          <>
                            <span className="text-sm text-muted-foreground">in</span>
                            <button
                              onClick={() => window.open(`/organization?id=${post.organization!.id}`, '_blank')}
                              className="flex items-center space-x-1 bg-muted px-2 py-1 rounded-full hover:bg-muted/80 cursor-pointer"
                            >
                              <Building className="h-3 w-3 text-professional-blue" />
                              <span className="text-sm font-medium text-professional-blue hover:underline">
                                {post.organization.name}
                              </span>
                            </button>
                          </>
                        )}
                        
                        {post.bowl && (
                          <>
                            <span className="text-sm text-muted-foreground">in</span>
                            <button
                              onClick={() => window.open(`/bowl?id=${post.bowl!.id}`, '_blank')}
                              className="flex items-center space-x-1 bg-muted px-2 py-1 rounded-full hover:bg-muted/80 cursor-pointer"
                            >
                              <Users className="h-3 w-3 text-reddit-orange" />
                              <span className="text-sm font-medium text-reddit-orange hover:underline">
                                {post.bowl.name}
                              </span>
                            </button>
                          </>
                        )}
                      </div>

                      {/* Post Title */}
                      <h1 className="text-2xl font-bold text-foreground mb-3 leading-tight">
                        {post.title}
                      </h1>
                      
                      {/* Post Content */}
                      {post.type === 'poll' ? (
                        <div 
                          className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 mb-4 cursor-pointer hover:shadow-md transition-all duration-300"
                          onClick={handlePollClick}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                                <BarChart3 className="w-5 h-5 text-white" />
                              </div>
                              <div>
                                <h3 className="font-semibold text-foreground mb-1">Poll</h3>
                                <p className="text-sm text-muted-foreground">{post.content}</p>
                              </div>
                            </div>
                            <div className="flex items-center space-x-2 text-blue-600 dark:text-blue-400">
                              <span className="text-sm font-medium">View Poll</span>
                              <ChevronRight className="w-4 h-4" />
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="text-muted-foreground mb-4 leading-relaxed whitespace-pre-wrap">
                          <div className="whitespace-pre-wrap">
                            {post.content}
                          </div>
                        </div>
                      )}

                      {/* Attached Image */}
                      {post.imageUrl && (
                        <img 
                          src={post.imageUrl} 
                          alt="Post attachment" 
                          className="rounded-lg mb-4 w-full max-h-96 object-cover shadow-lg"
                        />
                      )}

                      {/* Post Actions */}
                      <div className="flex items-center space-x-6 text-muted-foreground text-sm">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => setShowComments(!showComments)}
                          className="flex items-center space-x-1 hover:text-professional-blue p-2 rounded-lg transition-all duration-300"
                        >
                          <MessageSquare className="h-4 w-4" />
                          <span>{post.commentCount} comments</span>
                        </Button>
                        
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="flex items-center space-x-1 hover:text-reddit-orange p-2 rounded-lg transition-all duration-300"
                        >
                          <Share2 className="h-4 w-4" />
                          <span>Share</span>
                        </Button>
                        
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="flex items-center space-x-1 hover:text-positive p-2 rounded-lg transition-all duration-300"
                        >
                          <Bookmark className="h-4 w-4" />
                          <span>Save</span>
                        </Button>
                      </div>

                      {/* Comments Section */}
                      {showComments && (
                        <div className="mt-6 pt-6 border-t">
                          {/* Comment Form - Moved to top like Reddit */}
                          <div className="mb-6">
                            <CommentForm postId={post.id} onSuccess={refetchComments} />
                          </div>

                          {commentsLoading ? (
                            <div className="text-center text-muted-foreground py-4">
                              <div className="animate-spin h-6 w-6 border-2 border-reddit-orange border-t-transparent rounded-full mx-auto"></div>
                              <p className="mt-2">Loading comments...</p>
                            </div>
                          ) : comments && comments.length > 0 ? (
                            <div className="space-y-4">
                              {comments.map((comment, index) => (
                                <div 
                                  key={comment.id} 
                                  className="animate-fade-in-up bg-muted rounded-lg p-4"
                                  style={{ animationDelay: `${index * 100}ms` }}
                                >
                                  <CommentReply
                                    comment={comment}
                                    postId={post.id}
                                    onSuccess={refetchComments}
                                    depth={0}
                                  />
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div className="text-center py-12">
                              <div className="mb-6">
                                <div className="w-16 h-16 bg-gray-100 dark:bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-4">
                                  <MessageSquare className="h-8 w-8 text-gray-400" />
                                </div>
                                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                                  Be the first to comment
                                </h3>
                                <p className="text-gray-500 dark:text-gray-400 text-sm">
                                  Nobody's responded to this post yet. Add your thoughts and get the conversation going.
                                </p>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 shadow-sm">
                <CardContent className="p-12 text-center">
                  <div className="mb-6">
                    <MessageSquare className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                    Post not found
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400 mb-6">
                    The post you're looking for doesn't exist or has been removed.
                  </p>
                  <Button 
                    onClick={() => setLocation("/")}
                    className="bg-reddit-orange hover:bg-reddit-orange/90 text-white"
                  >
                    Back to Feed
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </main>
      </div>
    </div>
  );
} 